import http from 'node:http';
import { createMemoryStore } from '../src/store/memory.js';
import { createEvidenceModule } from '../src/module.js';
import { signJwt } from '../src/http.js';
import { seedDemo } from '../src/seed/demo.js';

export const SECRET = 'test-secret';

export async function start({ gemini } = {}) {
  const store = createMemoryStore();
  await seedDemo(store);
  await store.collection('startups').insert({ _id: 'other-startup', name: 'Other', ownerId: 'someone-else', evaluation: { claims: [{ externalId: 'x', title: 'Other claim' }] } });
  const config = { jwtSecret: SECRET, geminiKey: '', sourceCheck: false, demoMode: true };
  const mod = createEvidenceModule({
    store, config, logger: { error() {} },
    adapters: gemini === undefined ? {} : { gemini },
  });
  const server = http.createServer(async (req, res) => {
    if (!(await mod.handle(req, res))) { res.writeHead(404); res.end(); }
  });
  await new Promise((r) => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const token = (id = 'demo-user') => signJwt({ sub: id }, SECRET);
  async function call(method, path, { body, as = 'demo-user', raw } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (as) headers.Authorization = `Bearer ${raw ?? token(as)}`;
    const r = await fetch(base + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, body: await r.json() };
  }
  return { store, call, close: () => new Promise((r) => server.close(r)), token };
}

/** Fake Gemini client. `reply` is a function (userPrompt) => string, or an Error to throw. */
export const fakeGemini = (reply) => ({
  configured: true,
  calls: [],
  async analyze(args) {
    this.calls.push(args);
    const out = typeof reply === 'function' ? reply(args) : reply;
    if (out instanceof Error) throw out;
    return out;
  },
});

export const SURVEY = (over = {}) => ({
  title: 'Campus survey', description: 'We surveyed 100 students about interest in the product.',
  type: 'customer_survey', sampleSize: 100, positiveCount: 25, evidenceDate: '2026-09-01', ...over,
});

export async function claimId(call, text = '80%') {
  const r = await call('GET', '/startups/demo-startup/claims');
  return r.body.claims.find((c) => c.claimText.includes(text))._id;
}
