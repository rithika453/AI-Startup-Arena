# Member 5: Evidence, Validation & Innovation Module

Three features for the AI Startup Evaluation Platform:

1. **Evidence-Based Validation**: attach evidence to AI-generated claims; checked by rules, numbers and Gemini.
2. **Contradiction Timeline**: potential conflicts between claims and evidence, with review / resolve / dismiss.
3. **Weakness-to-Action Task Tracker**: weaknesses, evidence gaps and contradictions become tasks.

> **Important: read first.** Your existing repository (Members 1–4) was **not available** when this was built, so nothing here was
> tested against it. The module is self-contained and talks to the rest of the app through **one file of adapters**
> (`src/integration/adapters.js`). It runs standalone with demo data. Follow "Integrating" below to connect it.

## Run the demo (no installs needed)

Requires Node 20+. There are **no npm dependencies** (MongoDB driver is optional).

```bash
cp .env.example .env        # optional; DEMO_MODE=true is already the default in .env.example
npm run demo                # http://localhost:4000, in-memory store, auto-login as the demo founder
npm test                    # 30 tests
```

Without `GEMINI_API_KEY` the app still works: rule and numerical validation run, and evidence that needs AI stays
"Not Yet Validated" with a clear message (nothing is fabricated).

### Demo walkthrough (fictional startup "CampusCart", all labelled DEMO DATA)
1. Open the app. The six AI claims appear (from the seeded evaluation).
2. Select **"80% of surveyed customers are interested…"**. Submit a *Customer survey* with sample size **100**, positive responses **25**.
3. Result: *Contradicting Evidence*: "25 of 100 = 25% (95% range about 17.5%–34.3%)", with sample-size limitations. The source status shows separately as "Not Checked".
4. A **potential contradiction** appears on the timeline (severity High) with a suggested task to run further customer research.
5. Mark the task *In Progress*. Submit a larger survey later (e.g. 500 / 410). The claim now shows conflicting evidence, and the contradiction gets a note but is **not** auto-resolved. Review, then resolve or dismiss it with an explanation.
6. Completing a task prompts you to submit the results as evidence; it never marks the weakness as fixed.

## Integrating with Members 1–4

Mount the router in your Express app:

```js
import { createEvidenceModule, createStore, loadConfig } from './startup-evidence-module/src/module.js';
const config = loadConfig();
const store = await createStore(config);                 // MongoDB if MONGODB_URI is set
const evidence = createEvidenceModule({ store, config, adapters: { /* overrides, see below */ } });
app.use('/api', evidence.middleware);                    // unknown routes fall through to next()
```

Edit the adapters (or pass overrides) to point at the real code:

| Adapter | Replace with | Default (demo) |
|---|---|---|
| `authenticate(req)` | Member 1's token check, returns `{id, name}` | HS256 JWT signed with `JWT_SECRET` (`sub`/`id`/`userId`) |
| `getStartup(id)` | Member 2's Startup model lookup (needs an owner id) | this module's `startups` collection |
| `canAccessStartup(user, startup)` | Member 2's ownership rule | owner or `collaboratorIds` |
| `getEvaluationClaims(startup)` | Member 4's claims → `{externalId, title, description?, category?, origin?}` | `startup.evaluation.claims` |
| `getEvaluationRisks(startup)` | Member 4's risks → `{id, title, description?, category?, severity?}` (optional) | `startup.evaluation.risks` |
| `gemini.analyze({systemInstruction, userPrompt})` | Member 4's Gemini client, returns raw JSON text | small `fetch` client using `GEMINI_API_KEY` |

Use the **same JWT secret** as your auth, keep the Gemini key on the server, and set `DEMO_MODE=false` in any real deployment.
Frontend: `public/` is a framework-free dashboard (`index.html`, `app.js`, `styles.css`). Port the three screens into your
framework or serve `public/` as is. It reuses none of Members' components because they were not available.

## API (all require `Authorization: Bearer <token>`; startup access is checked on every call, returning 404 otherwise)

| Method & path | Purpose |
|---|---|
| `GET /startups/:id/claims` | Claims from the AI evaluation (imported once, never duplicated) + evidence status/count |
| `GET /startups/:id/evidence[?claimId=]` | Evidence records |
| `POST /startups/:id/evidence` | Submit + validate evidence (400 field errors, 409 duplicate) |
| `GET /evidence/:id` | Evidence + full validation history |
| `POST /evidence/:id/validate` | Re-run validation (history is appended, never overwritten) |
| `POST /evidence/:id/source-review` | Mark source "independently reviewed" (must be a different user than the submitter) |
| `GET /startups/:id/contradictions[?status=&order=asc\|desc]` | Timeline (newest first by default) |
| `GET /contradictions/:id` | Detail: claims, evidence, event history |
| `PATCH /contradictions/:id` | `{status: under_review\|resolved\|dismissed\|open, notes}`; resolve/dismiss/reopen need notes |
| `GET /startups/:id/tasks[?status=&priority=&due=overdue\|today\|week\|none]` | Task list |
| `POST /startups/:id/tasks` | `{generate:true}` generates from weaknesses (idempotent), or `{title, description?, priority?, relatedClaimId?}` for a manual task |
| `GET /tasks/:id`, `PATCH /tasks/:id` | Detail; `{status, priority, dueDate, completionNotes}` |

Routes that already exist in your app under the same paths will conflict. Check before mounting.

## How validation works
* **Rules**: required fields, URL/date/number formats, sample size required with counts, positives ≤ sample. A complete form is **not** treated as credible; missing information is listed.
* **Numerical**: compares claim figures only when metric, unit and period match. Percentages use a 95% Wilson interval, so small samples give "insufficient" rather than a false conclusion. Handles "at least / below" claims, currency (₹/$, k/lakh/crore) and competitor counts.
* **Semantic (Gemini)**: gets only the claim and evidence, treats evidence text as untrusted data (JSON-encoded inside a delimited block, system rules say never to follow it), requires strict JSON, validates it, and never claims a source was verified.
* **Combining**: numeric contradiction wins; numeric support + AI doubt → insufficient; AI failure → evidence kept, status pending, no invented result.
* Source verification (`not_checked / accessible / unavailable / independently_reviewed`) is stored **separately**. Optional `SOURCE_CHECK=true` probes URLs with SSRF protection; accessible ≠ credible.

## Environment variables
`PORT`, `MONGODB_URI`, `MONGODB_DB`, `JWT_SECRET`, `DEMO_MODE`, `GEMINI_API_KEY`, `GEMINI_MODEL`, `GEMINI_TIMEOUT_MS`, `SOURCE_CHECK` (see `.env.example`).

## Files
`src/module.js` (entry), `src/integration/*` (adapters, Gemini), `src/services/{rules,numeric,semantic,evidence,contradictions,tasks}.js`,
`src/routes/api.js`, `src/store/{memory,mongo}.js`, `src/server.js` (standalone server), `src/seed/demo.js`, `public/*`, `test/*`.
Data collections (prefixed `m5_` in MongoDB): claims, evidence, validations, contradictions, contradiction_events, tasks.

## Status
**Done and tested:** all three features end to end (30 automated tests: rules, numerics, semantic parsing/injection handling, auth/ownership, duplicates, contradiction lifecycle and history, task dedupe/filters/due dates, AI failure paths), plus a real-browser run of the full demo flow in Chromium.

**Not done / known limits:**
* Not tested against the real Members 1–4 code, database models or UI components (unavailable).
* The MongoDB store (`src/store/mongo.js`) was **never run against a live MongoDB** (none available); the in-memory store is what the tests cover.
* Gemini was only tested with a fake client; the real `gemini.js` request was not exercised. Check the model name for your API key.
* No file uploads (text and URL only), as the brief says when secure storage is absent.
* Contradiction detection covers numeric conflicts (percent, money, competitor count) and AI-flagged conflicts for a single claim; it does not compare two claims with each other or diff evaluation snapshots.
* "Independently reviewed" needs a second user; the demo has one account, so that path is covered by tests only.
* No rate limiting. Add it at your gateway.

**Depends on other members:** Member 1 (auth token format), Member 2 (startup model/ownership), Member 4 (claims, risks, Gemini client).
