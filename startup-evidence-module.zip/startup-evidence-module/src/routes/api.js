import { HttpError, assertId, createRouter } from '../http.js';
import { validateEvidenceInput, EVIDENCE_TYPES } from '../services/rules.js';
import { syncClaims, summarizeClaim, fingerprint, validateEvidence, CAVEAT, VALIDATION_LABELS } from '../services/evidence.js';
import { updateContradiction, CONTRADICTION_STATUSES } from '../services/contradictions.js';
import { generateTasks, applyTaskPatch, filterAndSortTasks, createManualTaskInput, ensureTask } from '../services/tasks.js';

const now = () => new Date().toISOString();

export function createApiRouter(ctx) {
  const r = createRouter();
  const { store, adapters } = ctx;

  /** Load a startup and make sure this user may access it. 404 for both missing and forbidden (no enumeration). */
  async function startupFor(user, startupId) {
    assertId(startupId, 'startup id');
    const startup = await adapters.getStartup(startupId);
    if (!startup || !(await adapters.canAccessStartup(user, startup))) throw new HttpError(404, 'Startup not found');
    return startup;
  }
  async function evidenceFor(user, evidenceId) {
    assertId(evidenceId, 'evidence id');
    const evidence = await store.collection('evidence').get(evidenceId);
    if (!evidence) throw new HttpError(404, 'Evidence not found');
    const startup = await startupFor(user, evidence.startupId);
    return { evidence, startup };
  }
  async function contradictionFor(user, id) {
    assertId(id, 'contradiction id');
    const c = await store.collection('contradictions').get(id);
    if (!c) throw new HttpError(404, 'Contradiction not found');
    const startup = await startupFor(user, c.startupId);
    return { contradiction: c, startup };
  }
  async function taskFor(user, id) {
    assertId(id, 'task id');
    const t = await store.collection('tasks').get(id);
    if (!t) throw new HttpError(404, 'Task not found');
    const startup = await startupFor(user, t.startupId);
    return { task: t, startup };
  }
  const claimById = async (startupId, claimId) => {
    const c = typeof claimId === 'string' ? await store.collection('claims').get(claimId) : null;
    return c && c.startupId === startupId ? c : null;
  };

  const present = (e) => ({ ...e, validationLabel: VALIDATION_LABELS[e.validationStatus], caveat: CAVEAT });

  // ---------------- Claims ----------------
  r.get('/startups/:startupId/claims', async ({ user, params }) => {
    const startup = await startupFor(user, params.startupId);
    const claims = await syncClaims(ctx, startup);
    const evidence = await store.collection('evidence').find({ startupId: startup._id });
    return {
      body: {
        claims: claims.map((c) => ({ ...c, ...summarizeClaim(evidence.filter((e) => e.claimId === c._id)) })),
        evidenceTypes: EVIDENCE_TYPES,
        startup: { id: startup._id, name: startup.name, demo: Boolean(startup.demo) },
      },
    };
  });

  // ---------------- Evidence ----------------
  r.get('/startups/:startupId/evidence', async ({ user, params, query }) => {
    const startup = await startupFor(user, params.startupId);
    const filter = { startupId: startup._id };
    if (query.claimId) filter.claimId = assertId(query.claimId, 'claim id');
    const rows = await store.collection('evidence').find(filter, { sort: { createdAt: -1 } });
    return { body: { evidence: rows.map(present) } };
  });

  r.post('/startups/:startupId/evidence', async ({ user, params, readBody }) => {
    const startup = await startupFor(user, params.startupId);
    const body = await readBody();
    const claim = await claimById(startup._id, body.claimId);
    if (!claim) throw new HttpError(400, 'Choose a claim from this startup', { errors: [{ field: 'claimId', message: 'Select the claim this evidence relates to' }] });

    const { errors, missingInfo, clean } = validateEvidenceInput(body);
    if (errors.length) throw new HttpError(400, 'Please fix the highlighted fields', { errors });

    const fp = fingerprint(claim._id, clean);
    const dup = await store.collection('evidence').findOne({ startupId: startup._id, claimId: claim._id, fingerprint: fp });
    if (dup) throw new HttpError(409, 'This evidence has already been submitted for this claim', { existingEvidenceId: dup._id });

    const ts = now();
    const saved = await store.collection('evidence').insert({
      startupId: startup._id,
      claimId: claim._id,
      submittedBy: user.id,
      ...clean,
      fingerprint: fp,
      validationStatus: 'not_validated',
      sourceVerificationStatus: 'not_checked',
      validationExplanation: 'Waiting for validation.',
      validationDetails: { missingInformation: missingInfo },
      ruleMissingInfo: missingInfo,
      createdAt: ts,
      updatedAt: ts,
    });

    let result = { evidence: saved, contradiction: null, contradictionCreated: false, task: null, aiAvailable: false };
    try {
      result = await validateEvidence(ctx, { startup, claim, evidence: saved, actor: user.id });
    } catch (e) {
      ctx.logger?.error?.('validation failed', e.message); // evidence stays saved & pending
    }
    const evidence = (await store.collection('evidence').get(saved._id)) || saved;
    return {
      status: 201,
      body: {
        evidence: present(evidence),
        missingInformation: missingInfo,
        contradiction: result.contradiction,
        contradictionCreated: result.contradictionCreated,
        task: result.task,
        validationPending: evidence.validationStatus === 'not_validated',
        aiAvailable: result.aiAvailable,
      },
    };
  });

  r.get('/evidence/:evidenceId', async ({ user, params }) => {
    const { evidence } = await evidenceFor(user, params.evidenceId);
    const history = await store.collection('validations').find({ evidenceId: evidence._id }, { sort: { at: -1 } });
    return { body: { evidence: present(evidence), history } };
  });

  r.post('/evidence/:evidenceId/validate', async ({ user, params }) => {
    const { evidence, startup } = await evidenceFor(user, params.evidenceId);
    const claim = await store.collection('claims').get(evidence.claimId);
    if (!claim) throw new HttpError(404, 'Claim not found');
    const result = await validateEvidence(ctx, { startup, claim, evidence, actor: user.id });
    return {
      body: {
        evidence: present(result.evidence), contradiction: result.contradiction,
        contradictionCreated: result.contradictionCreated, task: result.task, aiAvailable: result.aiAvailable,
        validationPending: result.evidence.validationStatus === 'not_validated',
      },
    };
  });

  // Independent review of a source: must be done by someone other than the submitter.
  r.post('/evidence/:evidenceId/source-review', async ({ user, params, readBody }) => {
    const { evidence } = await evidenceFor(user, params.evidenceId);
    if (evidence.submittedBy === user.id) throw new HttpError(403, 'A source must be reviewed by someone other than the person who submitted it');
    const body = await readBody();
    const note = typeof body.note === 'string' ? body.note.trim() : '';
    if (note.length < 5) throw new HttpError(400, 'Add a short note describing what you checked', { errors: [{ field: 'note', message: 'A note is required' }] });
    const updated = await store.collection('evidence').update(evidence._id, {
      sourceVerificationStatus: 'independently_reviewed', sourceReviewNote: note.slice(0, 1000), sourceReviewedBy: user.id, updatedAt: now(),
    });
    return { body: { evidence: present(updated) } };
  });

  // ---------------- Contradictions ----------------
  r.get('/startups/:startupId/contradictions', async ({ user, params, query }) => {
    const startup = await startupFor(user, params.startupId);
    const order = query.order === 'asc' ? 1 : -1;
    let rows = await store.collection('contradictions').find({ startupId: startup._id }, { sort: { detectedAt: order } });
    if (query.status && CONTRADICTION_STATUSES.includes(query.status)) rows = rows.filter((c) => c.status === query.status);
    const claims = await store.collection('claims').find({ startupId: startup._id });
    const evidence = await store.collection('evidence').find({ startupId: startup._id });
    const out = rows.map((c) => ({
      ...c,
      claims: claims.filter((x) => c.claimIds.includes(x._id)).map((x) => ({ _id: x._id, claimText: x.claimText, category: x.category })),
      evidence: evidence.filter((x) => c.evidenceIds.includes(x._id)).map((x) => ({ _id: x._id, title: x.title, type: x.type, validationStatus: x.validationStatus })),
    }));
    return { body: { contradictions: out } };
  });

  r.get('/contradictions/:contradictionId', async ({ user, params }) => {
    const { contradiction } = await contradictionFor(user, params.contradictionId);
    const [claims, evidence, events] = await Promise.all([
      Promise.all(contradiction.claimIds.map((id) => store.collection('claims').get(id))),
      Promise.all(contradiction.evidenceIds.map((id) => store.collection('evidence').get(id))),
      store.collection('contradiction_events').find({ contradictionId: contradiction._id }, { sort: { at: 1 } }),
    ]);
    return { body: { contradiction, claims: claims.filter(Boolean), evidence: evidence.filter(Boolean).map(present), events } };
  });

  r.patch('/contradictions/:contradictionId', async ({ user, params, readBody }) => {
    const { contradiction } = await contradictionFor(user, params.contradictionId);
    const updated = await updateContradiction(ctx, contradiction, await readBody(), user);
    return { body: { contradiction: updated } };
  });

  // ---------------- Tasks ----------------
  r.get('/startups/:startupId/tasks', async ({ user, params, query }) => {
    const startup = await startupFor(user, params.startupId);
    const all = await store.collection('tasks').find({ startupId: startup._id });
    const claims = await store.collection('claims').find({ startupId: startup._id });
    const cons = await store.collection('contradictions').find({ startupId: startup._id });
    const tasks = filterAndSortTasks(all, query).map((t) => ({
      ...t,
      claim: claims.filter((c) => c._id === t.relatedClaimId).map((c) => ({ _id: c._id, claimText: c.claimText }))[0] || null,
      contradiction: cons.filter((c) => c._id === t.relatedContradictionId).map((c) => ({ _id: c._id, title: c.title, status: c.status }))[0] || null,
    }));
    return { body: { tasks, total: all.length } };
  });

  r.post('/startups/:startupId/tasks', async ({ user, params, readBody }) => {
    const startup = await startupFor(user, params.startupId);
    const body = await readBody();
    if (body.generate === true) {
      const claims = await syncClaims(ctx, startup);
      const { created, reused } = await generateTasks(ctx, startup, claims);
      return { status: created.length ? 201 : 200, body: { created, reused } };
    }
    const input = createManualTaskInput(body);
    let claimId = null;
    if (body.relatedClaimId) {
      const claim = await claimById(startup._id, body.relatedClaimId);
      if (!claim) throw new HttpError(400, 'Related claim not found', { errors: [{ field: 'relatedClaimId', message: 'Claim not found' }] });
      claimId = claim._id;
    }
    const { task, created } = await ensureTask(ctx, startup._id, {
      dedupeKey: `manual:${input.title.toLowerCase()}:${claimId || ''}`,
      relatedClaimId: claimId,
      ...input,
      reason: 'Added manually by a founder.',
      weakness: input.description || input.title,
      source: 'manual',
    });
    return { status: created ? 201 : 200, body: { task, created } };
  });

  r.get('/tasks/:taskId', async ({ user, params }) => {
    const { task } = await taskFor(user, params.taskId);
    const [claim, contradiction, evidence] = await Promise.all([
      task.relatedClaimId ? store.collection('claims').get(task.relatedClaimId) : null,
      task.relatedContradictionId ? store.collection('contradictions').get(task.relatedContradictionId) : null,
      task.relatedEvidenceId ? store.collection('evidence').get(task.relatedEvidenceId) : null,
    ]);
    return { body: { task, claim, contradiction, evidence: evidence ? present(evidence) : null } };
  });

  r.patch('/tasks/:taskId', async ({ user, params, readBody }) => {
    const { task } = await taskFor(user, params.taskId);
    const patch = applyTaskPatch(task, await readBody());
    const updated = await store.collection('tasks').update(task._id, patch);
    return {
      body: {
        task: updated,
        // Completing a task does not resolve the weakness; point the founder to the next step.
        nextStep: patch.status === 'completed' && task.relatedClaimId
          ? { action: 'add_evidence', claimId: task.relatedClaimId, message: 'Submit the results as evidence on the related claim so they can be assessed.' }
          : null,
      },
    };
  });

  return r;
}
