import { HttpError, readJson, send } from './http.js';
import { createApiRouter } from './routes/api.js';
import { createDefaultAdapters } from './integration/adapters.js';
import { loadConfig } from './config.js';

/**
 * Create the Member 5 module.
 *
 *   const m = createEvidenceModule({ store, config, adapters? });
 *   app.use('/api', m.middleware);        // Express / Connect style (calls next() for unknown routes)
 *   // or: await m.handle(req, res)       // plain node:http; returns false if the route is not ours
 */
export function createEvidenceModule({ store, config = loadConfig(), adapters, logger = console }) {
  const ctx = { store, config, logger, adapters: null };
  ctx.adapters = { ...createDefaultAdapters({ store, config }), ...(adapters || {}) };
  const router = createApiRouter(ctx);

  async function handle(req, res) {
    const url = new URL(req.url, 'http://localhost');
    const hit = router.match(req.method, url.pathname);
    if (!hit) return false;
    try {
      const user = await ctx.adapters.authenticate(req);
      if (!user) throw new HttpError(401, 'Please sign in to continue');
      const query = Object.fromEntries(url.searchParams);
      const out = await hit.handler({ req, user, params: hit.params, query, readBody: () => readJson(req) });
      send(res, out.status || 200, out.body);
    } catch (e) {
      if (e instanceof HttpError) send(res, e.status, { error: e.message, ...(e.details || {}) });
      else {
        logger.error?.('Unhandled error:', e);
        send(res, 500, { error: 'Something went wrong. Please try again.' }); // no internals leaked
      }
    }
    return true;
  }

  const middleware = (req, res, next) => {
    handle(req, res).then((handled) => { if (!handled) next(); }, next);
  };

  return { handle, middleware, ctx };
}

export { createStore } from './store/index.js';
export { loadConfig } from './config.js';
