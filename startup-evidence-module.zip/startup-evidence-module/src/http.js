import { createHmac, timingSafeEqual } from 'node:crypto';

export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export function send(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(payload);
}

const MAX_BODY = 100 * 1024;

/** Reads a JSON body. Works whether or not Express's body parser already ran. */
export async function readJson(req) {
  if (req.body !== undefined && req.body !== null && typeof req.body === 'object') return req.body;
  if (!['POST', 'PATCH', 'PUT'].includes(req.method)) return {};
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw new HttpError(413, 'Request body too large');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('not an object');
    }
    return parsed;
  } catch {
    throw new HttpError(400, 'Request body must be a valid JSON object');
  }
}

/** Minimal router. Paths are relative to the mount point (e.g. /startups/:startupId/claims). */
export function createRouter() {
  const routes = [];
  const add = (method) => (path, handler) => {
    const keys = [];
    const pattern = new RegExp(
      '^' + path.replace(/:([A-Za-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$',
    );
    routes.push({ method, pattern, keys, handler });
  };
  return {
    get: add('GET'),
    post: add('POST'),
    patch: add('PATCH'),
    routes,
    match(method, pathname) {
      for (const r of routes) {
        if (r.method !== method) continue;
        const m = r.pattern.exec(pathname);
        if (m) {
          const params = {};
          r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
          return { handler: r.handler, params };
        }
      }
      return null;
    },
  };
}

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
export function assertId(value, name = 'id') {
  if (typeof value !== 'string' || !ID_RE.test(value)) throw new HttpError(400, `Invalid ${name}`);
  return value;
}

// ---- Minimal HS256 JWT verify/sign (compatible with tokens from the `jsonwebtoken` package) ----
const b64u = (buf) => Buffer.from(buf).toString('base64url');

export function signJwt(payload, secret, expiresInSec = 8 * 3600) {
  const header = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64u(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + expiresInSec }));
  const sig = createHmac('sha256', secret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

export function verifyJwt(token, secret) {
  if (!secret || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString());
    if (header.alg !== 'HS256') return null; // reject "none" and other algorithms
    const expected = createHmac('sha256', secret).update(`${parts[0]}.${parts[1]}`).digest();
    const actual = Buffer.from(parts[2], 'base64url');
    if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return null;
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    if (payload.exp && payload.exp < Date.now() / 1000) return null;
    return payload;
  } catch {
    return null;
  }
}
