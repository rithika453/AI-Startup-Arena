import { createMemoryStore } from './memory.js';
import { createMongoStore } from './mongo.js';

export async function createStore(config) {
  if (config.mongoUri) return createMongoStore({ uri: config.mongoUri, dbName: config.dbName });
  return createMemoryStore();
}
