import { randomUUID } from 'node:crypto';

const clone = (v) => structuredClone(v);

function matches(doc, filter) {
  return Object.entries(filter).every(([k, v]) => {
    const dv = doc[k];
    if (Array.isArray(dv) && !Array.isArray(v)) return dv.includes(v); // Mongo-style "array contains"
    return dv === v;
  });
}

/** In-memory store with the same tiny API as the Mongo store. Used for demo + tests. */
export function createMemoryStore() {
  const cols = new Map();
  const collection = (name) => {
    if (!cols.has(name)) cols.set(name, new Map());
    const m = cols.get(name);
    return {
      async insert(doc) {
        const d = { ...clone(doc), _id: doc._id ?? randomUUID() };
        m.set(d._id, d);
        return clone(d);
      },
      async get(id) {
        const d = m.get(String(id));
        return d ? clone(d) : null;
      },
      async find(filter = {}, opts = {}) {
        const rows = [...m.values()].filter((d) => matches(d, filter));
        if (opts.sort) {
          const [[k, dir]] = Object.entries(opts.sort);
          rows.sort((a, b) => (a[k] > b[k] ? 1 : a[k] < b[k] ? -1 : 0) * dir);
        }
        return rows.map(clone);
      },
      async findOne(filter) {
        const d = [...m.values()].find((x) => matches(x, filter));
        return d ? clone(d) : null;
      },
      async update(id, patch) {
        const d = m.get(String(id));
        if (!d) return null;
        Object.assign(d, clone(patch));
        return clone(d);
      },
    };
  };
  return { kind: 'memory', collection, async close() {} };
}
