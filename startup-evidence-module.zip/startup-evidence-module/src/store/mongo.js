import { randomUUID } from 'node:crypto';

/**
 * MongoDB-backed store. Requires the optional `mongodb` package (npm install mongodb).
 * Documents use string _id values (UUIDs) so ids are uniform across both stores.
 * Timestamps are stored as ISO strings.
 *
 * NOTE: this file could not be run against a live MongoDB in the build environment
 * (no npm registry / mongod access). It is a thin wrapper; test it with your own database.
 */
export async function createMongoStore({ uri, dbName }) {
  let mongodb;
  try {
    mongodb = await import('mongodb');
  } catch {
    throw new Error('MONGODB_URI is set but the "mongodb" package is not installed. Run: npm install mongodb');
  }
  const client = new mongodb.MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
  await client.connect();
  const db = client.db(dbName);

  const collection = (name) => {
    const c = db.collection(`m5_${name}`);
    return {
      async insert(doc) {
        const d = { ...doc, _id: doc._id ?? randomUUID() };
        await c.insertOne(d);
        return d;
      },
      async get(id) {
        return c.findOne({ _id: String(id) });
      },
      async find(filter = {}, opts = {}) {
        let cur = c.find(filter);
        if (opts.sort) cur = cur.sort(opts.sort);
        return cur.toArray();
      },
      async findOne(filter) {
        return c.findOne(filter);
      },
      async update(id, patch) {
        return c.findOneAndUpdate({ _id: String(id) }, { $set: patch }, { returnDocument: 'after' });
      },
    };
  };

  // Indexes that back the common lookups.
  await Promise.all([
    collection('claims'), // ensure handles exist
  ]);
  await db.collection('m5_claims').createIndex({ startupId: 1, externalId: 1 }, { unique: true });
  await db.collection('m5_evidence').createIndex({ startupId: 1, claimId: 1 });
  await db.collection('m5_contradictions').createIndex({ startupId: 1, detectedAt: -1 });
  await db.collection('m5_tasks').createIndex({ startupId: 1, status: 1 });

  return { kind: 'mongo', collection, async close() { await client.close(); } };
}
