/** DEMO DATA ONLY. A fictional startup standing in for Member 4's evaluation output. */
export const DEMO_USER = { id: 'demo-user', name: 'Demo Founder' };
export const DEMO_STARTUP_ID = 'demo-startup';

export async function seedDemo(store) {
  const col = store.collection('startups');
  if (await col.get(DEMO_STARTUP_ID)) return;
  await col.insert({
    _id: DEMO_STARTUP_ID,
    name: 'DEMO DATA: CampusCart (fictional startup)',
    demo: true,
    ownerId: DEMO_USER.id,
    collaboratorIds: [],
    evaluation: {
      claims: [
        { externalId: 'c-demand', title: '80% of surveyed customers are interested in this product.', description: 'High customer demand is expected among university students.', category: 'Customer Demand', origin: 'Market Agent (demo)' },
        { externalId: 'c-market', title: 'The target market is growing.', description: 'The student e-commerce segment is expected to keep growing.', category: 'Market', origin: 'Market Agent (demo)' },
        { externalId: 'c-pricing', title: 'The product pricing is competitive.', description: 'A 5% platform fee undercuts existing marketplaces.', category: 'Pricing', origin: 'Finance Agent (demo)' },
        { externalId: 'c-profit', title: 'The startup can reach profitability with monthly operating costs of about ₹50,000.', description: 'Assumes a lean team and low hosting costs.', category: 'Financial', origin: 'Finance Agent (demo)' },
        { externalId: 'c-compete', title: 'No direct competitors exist.', description: 'The product has a competitive advantage because nothing similar is available.', category: 'Competition', origin: 'Competition Agent (demo)' },
        { externalId: 'c-cac', title: 'Customer acquisition cost will stay below ₹200 per customer.', description: 'Referral-led growth should keep acquisition costs low.', category: 'Financial', origin: 'Finance Agent (demo)' },
      ],
      risks: [
        { id: 'r-market-sources', title: 'Market-size claims lack supporting sources', category: 'Market', severity: 'medium', description: 'Find credible market research, document the target segment and the assumptions behind the growth claim.' },
      ],
    },
  });
}
