import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createEvidenceModule, createStore, loadConfig } from './module.js';
import { send, signJwt } from './http.js';
import { seedDemo, DEMO_USER, DEMO_STARTUP_ID } from './seed/demo.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Tiny .env loader (no dependency). Real environment variables win.
const envFile = path.join(root, '.env');
if (existsSync(envFile)) {
  for (const line of readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !line.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
  }
}

const config = loadConfig();
if (!config.jwtSecret) {
  console.error('JWT_SECRET is required unless DEMO_MODE=true.');
  process.exit(1);
}
const store = await createStore(config);
if (config.demoMode) await seedDemo(store);
const mod = createEvidenceModule({ store, config });

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml' };
const SECURITY = {
  'Content-Security-Policy': "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) {
      if (url.pathname === '/api/health') return send(res, 200, { ok: true, store: store.kind, ai: mod.ctx.adapters.gemini.configured, demo: config.demoMode });
      if (url.pathname === '/api/config') return send(res, 200, { demoMode: config.demoMode, aiConfigured: mod.ctx.adapters.gemini.configured });
      if (url.pathname === '/api/demo/login' && req.method === 'POST') {
        if (!config.demoMode) return send(res, 404, { error: 'Not found' });
        return send(res, 200, { token: signJwt({ sub: DEMO_USER.id, name: DEMO_USER.name }, config.jwtSecret), startupId: DEMO_STARTUP_ID, user: DEMO_USER });
      }
      req.url = req.url.slice(4) || '/'; // strip "/api"
      if (!(await mod.handle(req, res))) send(res, 404, { error: 'Not found' });
      return;
    }
    const rel = url.pathname === '/' ? '/index.html' : url.pathname;
    const file = path.join(root, 'public', path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
    if (!file.startsWith(path.join(root, 'public') + path.sep) || !MIME[path.extname(file)]) {
      res.writeHead(404, SECURITY); return res.end('Not found');
    }
    const data = await readFile(file);
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)], ...SECURITY });
    res.end(data);
  } catch (e) {
    if (e.code === 'ENOENT') { res.writeHead(404, SECURITY); return res.end('Not found'); }
    console.error(e);
    send(res, 500, { error: 'Something went wrong. Please try again.' });
  }
});

server.listen(config.port, () => {
  console.log(`Evidence module running at http://localhost:${config.port}  (store: ${store.kind}, demo: ${config.demoMode}, AI: ${mod.ctx.adapters.gemini.configured ? 'on' : 'off'})`);
});
