/**
 * ===== INTEGRATION ADAPTERS — the ONLY file that should need editing to plug into Members 1–4 =====
 *
 * The existing repository was not available when this module was built, so nothing here assumes the
 * real shape of Members 1–4's code. Each adapter below is a small, documented contract with a
 * working default. Swap the implementation to point at the real thing.
 *
 *  authenticate(req)            -> { id, name? } | null     Member 1: verify the request's login token.
 *  getStartup(startupId)        -> startup | null           Member 2: load a startup (must include owner id).
 *  canAccessStartup(user, s)    -> boolean                  Member 2: ownership / collaborator check.
 *  getEvaluationClaims(startup) -> Claim[]                  Member 4: claims/findings from the AI evaluation.
 *  getEvaluationRisks(startup)  -> Risk[] (optional)        Member 4: risks/weaknesses used to generate tasks.
 *  gemini.analyze(...)          -> Promise<string>          Member 4: Gemini client (raw JSON text back).
 *
 * Claim contract returned by getEvaluationClaims:
 *   { externalId: string (stable id from the evaluation), title, description?, category?, origin? }
 *   The text used for numeric analysis is `description || title`.
 */
import { verifyJwt } from '../http.js';
import { createGeminiClient } from './gemini.js';

export function createDefaultAdapters({ store, config }) {
  return {
    /** Default: Bearer JWT (HS256) signed with JWT_SECRET. Payload must carry `sub` or `id` or `userId`. */
    async authenticate(req) {
      const header = req.headers?.authorization || '';
      const m = /^Bearer (.+)$/.exec(header);
      if (!m) return null;
      const payload = verifyJwt(m[1], config.jwtSecret);
      if (!payload) return null;
      const id = payload.sub || payload.id || payload.userId;
      return id ? { id: String(id), name: payload.name } : null;
    },

    /** Default: reads the `startups` collection of THIS module's store (demo). Replace with Member 2's model. */
    async getStartup(startupId) {
      return store.collection('startups').get(startupId);
    },

    /** Default: owner or listed collaborator. Replace with Member 2's ownership rule. */
    canAccessStartup(user, startup) {
      return startup.ownerId === user.id || (startup.collaboratorIds || []).includes(user.id);
    },

    /** Default: startup.evaluation.claims (demo shape). Replace with Member 4's stored evaluation output. */
    async getEvaluationClaims(startup) {
      const claims = startup?.evaluation?.claims;
      return Array.isArray(claims) ? claims : [];
    },

    /**
     * Optional. Risks / weaknesses from Member 4's evaluation: [{ id, title, description?, category?, severity? }].
     * Default: startup.evaluation.risks (demo shape). Used only to generate tasks.
     */
    async getEvaluationRisks(startup) {
      const risks = startup?.evaluation?.risks;
      return Array.isArray(risks) ? risks : [];
    },

    gemini: createGeminiClient({
      apiKey: config.geminiKey,
      model: config.geminiModel,
      timeoutMs: config.geminiTimeoutMs,
    }),
  };
}
