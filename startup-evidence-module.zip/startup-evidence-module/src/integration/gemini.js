/**
 * Standalone Gemini client used ONLY because Member 4's client was not available to inspect.
 * To reuse Member 4's integration instead, replace `adapters.gemini.analyze` in
 * src/integration/adapters.js with a function that has the same contract:
 *
 *    analyze({ systemInstruction, userPrompt }) -> Promise<string>   // raw JSON text
 *
 * The API key stays on the backend and is never sent to the browser.
 */
export function createGeminiClient({ apiKey, model, timeoutMs }) {
  return {
    configured: Boolean(apiKey),
    async analyze({ systemInstruction, userPrompt }) {
      if (!apiKey) {
        const e = new Error('Gemini API key not configured');
        e.code = 'AI_NOT_CONFIGURED';
        throw e;
      }
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      try {
        const resp = await fetch(url, {
          method: 'POST',
          signal: ctrl.signal,
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: systemInstruction }] },
            contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
            generationConfig: { temperature: 0.1, responseMimeType: 'application/json' },
          }),
        });
        if (!resp.ok) {
          const e = new Error(`Gemini request failed with status ${resp.status}`);
          e.code = 'AI_HTTP_ERROR';
          throw e;
        }
        const data = await resp.json();
        const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
        if (!text) {
          const e = new Error('Gemini returned an empty response');
          e.code = 'AI_EMPTY';
          throw e;
        }
        return text;
      } catch (err) {
        if (err.name === 'AbortError') {
          const e = new Error('Gemini request timed out');
          e.code = 'AI_TIMEOUT';
          throw e;
        }
        throw err;
      } finally {
        clearTimeout(timer);
      }
    },
  };
}
