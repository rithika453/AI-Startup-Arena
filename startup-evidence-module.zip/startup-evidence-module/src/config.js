import { randomBytes } from 'node:crypto';

export function loadConfig(env = process.env) {
  const demoMode = env.DEMO_MODE === 'true';
  return {
    port: Number(env.PORT) || 4000,
    mongoUri: env.MONGODB_URI || '',
    dbName: env.MONGODB_DB || 'startup_eval',
    // In demo mode a random secret is fine. In real use this MUST match Member 1's signing secret.
    jwtSecret: env.JWT_SECRET || (demoMode ? randomBytes(32).toString('hex') : ''),
    demoMode,
    geminiKey: env.GEMINI_API_KEY || '',
    geminiModel: env.GEMINI_MODEL || 'gemini-2.0-flash',
    geminiTimeoutMs: Number(env.GEMINI_TIMEOUT_MS) || 15000,
    sourceCheck: env.SOURCE_CHECK === 'true',
  };
}
