/**
 * Method 2: numerical validation.
 * Only compares quantities when metric/unit/period are comparable. Otherwise returns "insufficient"
 * or "not applicable" rather than guessing. Uncertainty from sample size is made explicit (Wilson interval).
 */

const MULT = { k: 1e3, lakh: 1e5, lakhs: 1e5, crore: 1e7, crores: 1e7, m: 1e6, million: 1e6 };

export function extractClaimFigures(text = '') {
  const out = {};
  const pct = /(\d+(?:\.\d+)?)\s*(?:%|percent\b|per cent\b)/i.exec(text);
  if (pct) out.percent = Number(pct[1]);

  const cur = /(₹|rs\.?|inr|\$|usd)\s*([\d,]+(?:\.\d+)?)\s*(k|lakhs?|crores?|m|million)?\b/i.exec(text);
  if (cur) {
    const sym = cur[1].toLowerCase();
    out.currency = sym === '$' || sym === 'usd' ? 'USD' : 'INR';
    out.amount = Number(cur[2].replace(/,/g, '')) * (cur[3] ? MULT[cur[3].toLowerCase()] : 1);
  }
  if (/\b(per month|monthly|a month|\/month|each month)\b/i.test(text)) out.period = 'month';
  else if (/\b(per year|yearly|annual(ly)?|a year|\/year)\b/i.test(text)) out.period = 'year';

  if (/\b(at least|over|more than|above|minimum of|greater than)\b/i.test(text)) out.bound = 'lower';
  else if (/\b(at most|under|less than|below|up to|maximum of|no more than|within)\b/i.test(text)) out.bound = 'upper';

  if (/\bno\s+(?:direct\s+|real\s+|significant\s+|serious\s+)?(?:competitors?|competition)\b/i.test(text)) out.noCompetitors = true;
  return out;
}

export function wilson(k, n, z = 1.96) {
  const p = k / n;
  const d = 1 + (z * z) / n;
  const c = p + (z * z) / (2 * n);
  const m = z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n));
  return { low: ((c - m) / d) * 100, high: ((c + m) / d) * 100 };
}

const r1 = (x) => Math.round(x * 10) / 10;
const fmtMoney = (n, cur) => `${cur === 'USD' ? '$' : '₹'}${Math.round(n).toLocaleString('en-IN')}`;

const NA = (explanation) => ({ applicable: false, status: 'not_applicable', explanation, limitations: [] });
const INSUFF = (explanation, extra = {}) => ({ applicable: true, status: 'insufficient', explanation, limitations: [], ...extra });

export function analyzeNumeric(claimText, nd = {}) {
  const fig = extractClaimFigures(claimText);
  const hasEvidenceNumbers = ['sampleSize', 'positiveCount', 'reportedValue', 'competitorCount'].some((k) => nd[k] !== undefined);
  if (!hasEvidenceNumbers) return NA('No numerical values were submitted with this evidence, so no numerical comparison was made.');

  // ---- Competitor count ----
  if (fig.noCompetitors && nd.competitorCount !== undefined) {
    if (nd.competitorCount > 0) {
      return {
        applicable: true, status: 'contradicting', metric: 'competitorCount', claimed: 0, observed: nd.competitorCount,
        severity: nd.competitorCount >= 3 ? 'high' : 'medium',
        explanation: `The claim says there are no direct competitors, but the submitted research identifies ${nd.competitorCount}. The claim needs revising (check the competitors really serve the same customers).`,
        limitations: ['Whether these competitors are truly "direct" depends on the evidence description and has not been verified.'],
      };
    }
    return {
      applicable: true, status: 'supporting', metric: 'competitorCount', claimed: 0, observed: 0,
      explanation: 'The submitted research reports zero competitors, which is consistent with the claim.',
      limitations: ['Finding no competitors in a search does not prove none exist (indirect substitutes, new entrants).'],
    };
  }

  // ---- Percentages ----
  if (fig.percent !== undefined && (nd.positiveCount !== undefined || (nd.unit === 'percent' && nd.reportedValue !== undefined))) {
    let n = nd.sampleSize;
    let k = nd.positiveCount;
    let observed;
    if (k !== undefined && n !== undefined) observed = (k / n) * 100;
    else if (nd.unit === 'percent' && nd.reportedValue !== undefined) {
      observed = nd.reportedValue;
      if (n !== undefined) k = Math.round((observed / 100) * n);
    }
    if (observed === undefined) return INSUFF('A positive-response count needs a sample size to compute a percentage.');

    const claimed = fig.percent;
    const limitations = ['Assumes the submitted result measures the same thing as the claim (e.g. "interested in the product"). Confirm this.'];
    let interval;
    if (n !== undefined && k !== undefined) {
      interval = wilson(k, n);
      if (n < 30) limitations.push(`Very small sample (n=${n}); results are highly uncertain.`);
      else if (n < 300) limitations.push(`Small sample (n=${n}); the margin of error is wide.`);
      limitations.push(`Sample size does not establish representativeness of the whole market.`);
    } else {
      limitations.push('No sample size was provided, so statistical uncertainty could not be estimated.');
    }
    const gap = Math.abs(claimed - observed);
    const severity = gap >= 30 ? 'high' : gap >= 15 ? 'medium' : 'low';
    const calc = n !== undefined && k !== undefined ? `${k} of ${n} = ${r1(observed)}%` : `${r1(observed)}%`;
    const range = interval ? ` (95% range about ${r1(interval.low)}%–${r1(interval.high)}%)` : '';
    const base = { applicable: true, metric: 'percent', claimed, observed: r1(observed), interval, severity, limitations };

    if (fig.bound === 'lower') {
      if (interval && interval.high < claimed) return { ...base, status: 'contradicting', explanation: `Claim: at least ${claimed}%. Submitted evidence: ${calc}${range}, which is below the claimed minimum.` };
      if (observed >= claimed) return { ...base, status: 'supporting', explanation: `Claim: at least ${claimed}%. Submitted evidence: ${calc}${range}, which meets the claimed minimum.` };
      return { ...base, status: 'insufficient', explanation: `Claim: at least ${claimed}%. Submitted evidence: ${calc}${range}. The observed value is below the claim but the sample is too small to rule it out.` };
    }
    if (fig.bound === 'upper') {
      if (interval && interval.low > claimed) return { ...base, status: 'contradicting', explanation: `Claim: at most ${claimed}%. Submitted evidence: ${calc}${range}, which is above the claimed maximum.` };
      if (observed <= claimed) return { ...base, status: 'supporting', explanation: `Claim: at most ${claimed}%. Submitted evidence: ${calc}${range}, which is within the claimed maximum.` };
      return { ...base, status: 'insufficient', explanation: `Claim: at most ${claimed}%. Submitted evidence: ${calc}${range}. The observed value is above the claim but the sample is too small to rule it out.` };
    }
    // approximate claim
    const outside = interval ? claimed < interval.low || claimed > interval.high : gap >= 10;
    if (outside && gap >= 10) {
      return { ...base, status: 'contradicting', explanation: `Claim: ${claimed}%. Submitted evidence: ${calc}${range}. The claimed value is outside what this evidence supports, so the evidence conflicts with the claim.` };
    }
    if (!outside && gap >= 10) {
      return { ...base, status: 'insufficient', explanation: `Claim: ${claimed}%. Submitted evidence: ${calc}${range}. The observed value differs from the claim, but the sample is too small to confirm or reject it.` };
    }
    return { ...base, status: 'supporting', explanation: `Claim: ${claimed}%. Submitted evidence: ${calc}${range}, which is consistent with the claim.` };
  }

  // ---- Money ----
  if (fig.amount !== undefined && nd.reportedValue !== undefined && ['INR', 'USD'].includes(nd.unit)) {
    if (nd.unit !== fig.currency) return INSUFF(`The claim is in ${fig.currency} but the evidence is in ${nd.unit}; no conversion is attempted, so no comparison was made.`);
    if (fig.period && nd.period && fig.period !== nd.period) {
      return INSUFF(`The claim is per ${fig.period} but the evidence is per ${nd.period}; these are not directly comparable.`);
    }
    if ((fig.period && !nd.period) || (!fig.period && nd.period)) {
      return INSUFF('The time period of the claim and the evidence do not clearly match (one of them has no period). Specify the period to compare them.');
    }
    const claimed = fig.amount;
    const observed = nd.reportedValue;
    const rel = claimed === 0 ? Infinity : Math.abs(observed - claimed) / claimed;
    const severity = rel >= 0.5 ? 'high' : rel >= 0.25 ? 'medium' : 'low';
    const txt = `Claim: ${fmtMoney(claimed, fig.currency)}${fig.period ? ` per ${fig.period}` : ''}. Submitted figure: ${fmtMoney(observed, nd.unit)}.`;
    const base = { applicable: true, metric: 'amount', claimed, observed, severity, limitations: ['Assumes the submitted figure covers the same items/scope as the claim.'] };
    if (fig.bound === 'upper') {
      return observed > claimed
        ? { ...base, status: 'contradicting', explanation: `${txt} The submitted figure exceeds the claimed upper limit.` }
        : { ...base, status: 'supporting', explanation: `${txt} The submitted figure is within the claimed limit.` };
    }
    if (fig.bound === 'lower') {
      return observed < claimed
        ? { ...base, status: 'contradicting', explanation: `${txt} The submitted figure is below the claimed minimum.` }
        : { ...base, status: 'supporting', explanation: `${txt} The submitted figure meets the claimed minimum.` };
    }
    return rel >= 0.15
      ? { ...base, status: 'contradicting', explanation: `${txt} The figures differ by ${Math.round(rel * 100)}%, which conflicts with the earlier assumption.` }
      : { ...base, status: 'supporting', explanation: `${txt} The figures are within ${Math.round(rel * 100)}% of each other.` };
  }

  return NA('The submitted numbers do not correspond to a figure in the claim with a comparable unit, so no numerical comparison was made.');
}
