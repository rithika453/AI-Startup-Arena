import { createHash } from 'node:crypto';
import dns from 'node:dns/promises';
import net from 'node:net';
import { analyzeNumeric } from './numeric.js';
import { analyzeSemantic } from './semantic.js';
import { reconcileContradictions } from './contradictions.js';
import { ensureTask, weakEvidenceTaskSpec } from './tasks.js';

const now = () => new Date().toISOString();

export const VALIDATION_LABELS = {
  not_validated: 'Not Yet Validated',
  supporting: 'Supporting Evidence',
  contradicting: 'Contradicting Evidence',
  insufficient: 'Insufficient Evidence',
  unrelated: 'Unrelated Evidence',
};

export const CAVEAT = 'Assessment is based only on the information you submitted. The underlying source has not been independently verified.';

/** Import the AI evaluation's claims into this module's claim collection without duplicating them. */
export async function syncClaims(ctx, startup) {
  const col = ctx.store.collection('claims');
  const incoming = (await ctx.adapters.getEvaluationClaims(startup)) || [];
  for (const c of incoming) {
    if (!c || typeof c.externalId !== 'string' || typeof c.title !== 'string' || !c.title.trim()) continue;
    const existing = await col.findOne({ startupId: startup._id, externalId: c.externalId });
    const fields = {
      claimText: c.title.trim().slice(0, 500),
      description: typeof c.description === 'string' ? c.description.slice(0, 2000) : '',
      category: typeof c.category === 'string' ? c.category.slice(0, 100) : 'General',
      origin: typeof c.origin === 'string' ? c.origin.slice(0, 200) : 'AI evaluation',
    };
    if (!existing) await col.insert({ startupId: startup._id, externalId: c.externalId, ...fields, createdAt: now() });
    else if (Object.keys(fields).some((k) => existing[k] !== fields[k])) await col.update(existing._id, fields);
  }
  return col.find({ startupId: startup._id }, { sort: { createdAt: 1 } });
}

/** Aggregate evidence statuses into a claim-level status. */
export function summarizeClaim(evidenceList) {
  const count = evidenceList.length;
  const s = new Set(evidenceList.map((e) => e.validationStatus));
  let status = 'not_validated';
  let note = 'No evidence has been submitted yet.';
  if (count) {
    const sup = s.has('supporting');
    const con = s.has('contradicting');
    if (sup && con) { status = 'insufficient'; note = 'Evidence conflicts: some supports the claim and some contradicts it. Review before relying on it.'; }
    else if (con) { status = 'contradicting'; note = 'Submitted evidence conflicts with this claim.'; }
    else if (sup) { status = 'supporting'; note = 'Submitted evidence is consistent with this claim (not proof).'; }
    else if (s.has('insufficient')) { status = 'insufficient'; note = 'Submitted evidence is not enough to judge this claim.'; }
    else if (s.has('unrelated')) { status = 'unrelated'; note = 'Submitted evidence does not appear related to this claim.'; }
    else { status = 'not_validated'; note = 'Evidence is waiting for validation.'; }
  }
  return { evidenceStatus: status, evidenceCount: count, statusNote: note };
}

export function fingerprint(claimId, clean) {
  return createHash('sha256')
    .update(JSON.stringify([claimId, clean.title.toLowerCase(), clean.description, clean.sourceUrl, clean.numericalData]))
    .digest('hex');
}

function combine(numeric, semantic) {
  const n = numeric.applicable ? numeric.status : null;
  const s = semantic.ok ? semantic.result.status : null;
  const methods = ['rules'];
  if (numeric.applicable) methods.push('numeric');
  if (semantic.ok) methods.push('semantic');
  let status;
  const parts = [];
  if (n) parts.push(numeric.explanation);
  if (s) parts.push(`Text analysis: ${semantic.result.explanation}`);

  if (n === 'contradicting') status = 'contradicting';
  else if (n === 'supporting') {
    if (!s || s === 'supporting') status = 'supporting';
    else { status = 'insufficient'; parts.push(`The numerical check is consistent with the claim but the text analysis returned "${s}". Please review.`); }
  } else if (n === 'insufficient') {
    status = s && s !== 'supporting' ? s : 'insufficient';
  } else if (s) status = s;
  else {
    status = 'not_validated';
    const why = semantic.reason === 'not_configured'
      ? 'AI analysis is not configured'
      : 'The AI analysis service was unavailable or returned an unusable response';
    parts.push(`${why}, and there were no comparable numbers. The evidence is saved and awaiting review. Use "Re-run validation" to try again.`);
  }
  return { status, methods, explanation: parts.join(' ') };
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const v = ip.toLowerCase();
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80') || v.startsWith('::ffff:');
}

/** Optional: is the URL reachable? Accessible does NOT mean credible. Guarded against SSRF. */
export async function checkSource(url) {
  try {
    const u = new URL(url);
    const addrs = await dns.lookup(u.hostname, { all: true });
    if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) return 'unavailable';
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    try {
      const r = await fetch(u, { method: 'HEAD', redirect: 'manual', signal: ctrl.signal });
      return r.status < 400 || (r.status >= 300 && r.status < 400) ? 'accessible' : 'unavailable';
    } finally { clearTimeout(timer); }
  } catch { return 'unavailable'; }
}

/**
 * Run all validation methods for one evidence record, store a history entry, update the evidence,
 * and reconcile contradictions/tasks. Never throws for AI problems.
 */
export async function validateEvidence(ctx, { startup, claim, evidence, actor }) {
  const numeric = analyzeNumeric(`${claim.claimText}. ${claim.description || ''}`, evidence.numericalData || {});
  const semantic = await analyzeSemantic(ctx.adapters.gemini, { claim, evidence, numeric });
  const { status, methods, explanation } = combine(numeric, semantic);

  const limitations = [...(numeric.limitations || []), ...(semantic.ok ? semantic.result.limitations : [])];
  if (evidence.limitations) limitations.push(`Founder note: ${evidence.limitations}`);
  const details = {
    numeric: numeric.applicable ? { status: numeric.status, claimed: numeric.claimed, observed: numeric.observed, interval: numeric.interval || null, metric: numeric.metric } : null,
    semantic: semantic.ok ? semantic.result : { unavailable: semantic.reason },
    supportingPoints: semantic.ok ? semantic.result.supportingPoints : [],
    contradictingPoints: semantic.ok ? semantic.result.contradictingPoints : [],
    missingInformation: semantic.ok ? semantic.result.missingInformation : [],
    limitations,
    methods,
  };
  const ts = now();
  await ctx.store.collection('validations').insert({
    evidenceId: evidence._id, startupId: startup._id, claimId: claim._id, at: ts, actor,
    status, explanation, methods, details, aiAvailable: semantic.ok,
  });

  let sourceVerificationStatus = evidence.sourceVerificationStatus || 'not_checked';
  if (ctx.config.sourceCheck && evidence.sourceUrl && sourceVerificationStatus !== 'independently_reviewed') {
    sourceVerificationStatus = await checkSource(evidence.sourceUrl);
  }

  const updated = await ctx.store.collection('evidence').update(evidence._id, {
    validationStatus: status,
    validationExplanation: explanation,
    validationDetails: details,
    validatedAt: ts,
    sourceVerificationStatus,
    updatedAt: ts,
  });

  const outcome = await reconcileContradictions(ctx, { startup, claim, evidence: updated, status, numeric, semantic, actor });
  let task = outcome.task;
  if (['insufficient', 'unrelated'].includes(status)) {
    task = (await ensureTask(ctx, startup._id, weakEvidenceTaskSpec(claim, updated))).task;
  }
  return { evidence: updated, contradiction: outcome.contradiction, contradictionCreated: outcome.created, task, aiAvailable: semantic.ok };
}
