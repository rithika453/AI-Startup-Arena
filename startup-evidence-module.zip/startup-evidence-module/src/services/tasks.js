import { HttpError } from '../http.js';

export const TASK_STATUSES = ['pending', 'in_progress', 'completed'];
export const PRIORITIES = ['low', 'medium', 'high'];
const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };

const now = () => new Date().toISOString();

export function inferTopic(claim) {
  const t = `${claim.category || ''} ${claim.claimText || ''}`.toLowerCase();
  if (/competitor|competition|advantage|differentiat/.test(t)) return 'competition';
  if (/demand|interest|customer|survey|adoption|willing/.test(t)) return 'demand';
  if (/cost|profit|revenue|financ|pricing|price|budget|cac|acquisition|margin|break-?even/.test(t)) return 'financial';
  if (/market|growth|growing|segment|tam\b/.test(t)) return 'market';
  return 'general';
}

const ACTIONS = {
  demand: {
    contradiction: ['Run further customer research and revise the demand assumption', 'Interview or survey more target customers (aim for a larger, representative sample), document the results, then update the demand figure used in your plan.'],
    gap: ['Validate customer demand', 'Conduct interviews or a survey with target customers, document the method and results, and attach them to this claim as evidence.'],
    weak: ['Strengthen the demand evidence', 'The current evidence is not enough to judge demand. Collect more responses from target customers and record sample size and method.'],
  },
  financial: {
    contradiction: ['Update the financial estimate and recalculate break-even', 'Replace the earlier assumption with the submitted figures, recalculate monthly costs and the break-even point, and document the new assumptions.'],
    gap: ['Back the financial assumption with data', 'Gather quotes, invoices or a worked calculation for this figure and attach it as evidence.'],
    weak: ['Strengthen the financial evidence', 'Provide a more complete calculation (scope, period and units) so this assumption can be compared properly.'],
  },
  competition: {
    contradiction: ['Revise the competitor and differentiation claim', 'Compare at least three relevant competitors, document your differentiating features, and update the claim.'],
    gap: ['Document the competitive landscape', 'Compare at least three relevant competitors and record what makes your product different.'],
    weak: ['Strengthen the competitor evidence', 'Add a structured comparison (features, pricing, target customers) of relevant competitors.'],
  },
  market: {
    contradiction: ['Re-check market-size assumptions', 'Find credible market research, document the target segment and assumptions, and update the claim.'],
    gap: ['Find credible market research', 'Locate credible market research, document the target segment and assumptions, and attach it as evidence.'],
    weak: ['Strengthen the market evidence', 'Add a credible, citable source and state the segment and time frame it covers.'],
  },
  general: {
    contradiction: ['Review and revise this claim', 'Review the conflicting evidence, decide whether the claim or the evidence is wrong, and update the plan.'],
    gap: ['Gather evidence for this claim', 'Collect evidence that tests this claim and attach it.'],
    weak: ['Strengthen the evidence for this claim', 'The current evidence is not enough to assess this claim. Add more specific evidence.'],
  },
};

/**
 * Create a task unless a similar one already exists for the same unresolved issue (same dedupeKey).
 * - non-completed task with the key -> reused (returned, nothing created)
 * - only completed tasks with the key -> a follow-up task is created only when `followUp` is true
 */
export async function ensureTask(ctx, startupId, spec, { followUp = false } = {}) {
  const col = ctx.store.collection('tasks');
  const existing = await col.find({ startupId, dedupeKey: spec.dedupeKey });
  const open = existing.find((t) => t.status !== 'completed');
  if (open) return { task: open, created: false };
  if (existing.length && !followUp) return { task: existing[existing.length - 1], created: false };
  const ts = now();
  const task = await col.insert({
    startupId,
    relatedClaimId: spec.relatedClaimId || null,
    relatedEvidenceId: spec.relatedEvidenceId || null,
    relatedContradictionId: spec.relatedContradictionId || null,
    title: spec.title,
    description: spec.description,
    reason: spec.reason,
    weakness: spec.weakness || spec.reason,
    priority: PRIORITIES.includes(spec.priority) ? spec.priority : 'medium',
    status: 'pending',
    dueDate: null,
    completionNotes: '',
    completedAt: null,
    source: spec.source || 'generated',
    dedupeKey: spec.dedupeKey,
    isFollowUp: existing.length > 0,
    createdAt: ts,
    updatedAt: ts,
  });
  return { task, created: true };
}

export function contradictionTaskSpec(claim, contradiction) {
  const [title, description] = ACTIONS[inferTopic(claim)].contradiction;
  return {
    dedupeKey: `contradiction:${contradiction._id}`,
    relatedClaimId: claim._id,
    relatedContradictionId: contradiction._id,
    relatedEvidenceId: contradiction.evidenceIds?.[0] || null,
    title: `${title}`,
    description: `${description}\n\nClaim: "${claim.claimText}"`,
    reason: `Potential contradiction detected: ${contradiction.description}`,
    weakness: `Evidence conflicts with the claim "${claim.claimText}"`,
    priority: contradiction.severity,
  };
}

export function weakEvidenceTaskSpec(claim, evidence) {
  const [title, description] = ACTIONS[inferTopic(claim)].weak;
  return {
    dedupeKey: `weak:${claim._id}`,
    relatedClaimId: claim._id,
    relatedEvidenceId: evidence?._id || null,
    title,
    description: `${description}\n\nClaim: "${claim.claimText}"`,
    reason: evidence ? `Submitted evidence "${evidence.title}" was assessed as insufficient or unrelated for this claim.` : 'Evidence is insufficient for this claim.',
    weakness: `Claim "${claim.claimText}" is not sufficiently validated`,
    priority: 'medium',
  };
}

export function gapTaskSpec(claim) {
  const [title, description] = ACTIONS[inferTopic(claim)].gap;
  return {
    dedupeKey: `gap:${claim._id}`,
    relatedClaimId: claim._id,
    title,
    description: `${description}\n\nClaim: "${claim.claimText}"`,
    reason: 'No evidence has been submitted for this AI-generated claim yet.',
    weakness: `Claim "${claim.claimText}" has no supporting evidence`,
    priority: 'medium',
  };
}

export function riskTaskSpec(risk) {
  return {
    dedupeKey: `risk:${risk.id}`,
    title: `Address risk: ${String(risk.title).slice(0, 120)}`,
    description: risk.description || `Investigate and mitigate this risk identified in the AI evaluation: ${risk.title}`,
    reason: `Risk identified in the AI evaluation${risk.category ? ` (${risk.category})` : ''}.`,
    weakness: String(risk.title),
    priority: PRIORITIES.includes(risk.severity) ? risk.severity : 'medium',
    source: 'evaluation',
  };
}

/** Generate tasks for all current weaknesses of a startup. Idempotent. */
export async function generateTasks(ctx, startup, claims) {
  const created = [];
  const reused = [];
  const push = (r) => (r.created ? created : reused).push(r.task);
  const evCol = ctx.store.collection('evidence');
  const coCol = ctx.store.collection('contradictions');

  for (const claim of claims) {
    const [evidence, cons] = await Promise.all([
      evCol.find({ startupId: startup._id, claimId: claim._id }),
      coCol.find({ startupId: startup._id, claimIds: claim._id }),
    ]);
    for (const c of cons.filter((x) => ['open', 'under_review'].includes(x.status))) {
      push(await ensureTask(ctx, startup._id, contradictionTaskSpec(claim, c), { followUp: true }));
    }
    if (!evidence.length) {
      push(await ensureTask(ctx, startup._id, gapTaskSpec(claim), { followUp: true }));
    } else if (!evidence.some((e) => e.validationStatus === 'supporting') &&
      evidence.some((e) => ['insufficient', 'unrelated', 'not_validated'].includes(e.validationStatus)) &&
      !evidence.some((e) => e.validationStatus === 'contradicting')) {
      push(await ensureTask(ctx, startup._id, weakEvidenceTaskSpec(claim, evidence[evidence.length - 1]), { followUp: true }));
    }
  }
  const risks = (await ctx.adapters.getEvaluationRisks?.(startup)) || [];
  for (const r of risks) {
    if (r && r.id && r.title) push(await ensureTask(ctx, startup._id, riskTaskSpec(r), { followUp: true }));
  }
  return { created, reused };
}

function todayStr() { return new Date().toISOString().slice(0, 10); }

export function validateDueDate(value, existing) {
  if (value === null || value === '') return null;
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(value))) {
    throw new HttpError(400, 'Due date must be a valid date (YYYY-MM-DD)', { errors: [{ field: 'dueDate', message: 'Enter a valid date (YYYY-MM-DD)' }] });
  }
  if (value !== existing && value < todayStr()) {
    throw new HttpError(400, 'Due date cannot be in the past', { errors: [{ field: 'dueDate', message: 'Due date cannot be in the past' }] });
  }
  return value;
}

export function createManualTaskInput(body) {
  const title = typeof body.title === 'string' ? body.title.trim() : '';
  const description = typeof body.description === 'string' ? body.description.trim() : '';
  const errors = [];
  if (!title) errors.push({ field: 'title', message: 'Task title is required' });
  else if (title.length > 200) errors.push({ field: 'title', message: 'Title must be 200 characters or fewer' });
  if (description.length > 3000) errors.push({ field: 'description', message: 'Description must be 3000 characters or fewer' });
  if (body.priority !== undefined && !PRIORITIES.includes(body.priority)) errors.push({ field: 'priority', message: 'Priority must be low, medium or high' });
  if (errors.length) throw new HttpError(400, 'Please fix the highlighted fields', { errors });
  return { title, description, priority: body.priority || 'medium' };
}

export function applyTaskPatch(task, body) {
  const errors = [];
  const patch = {};
  if (body.status !== undefined) {
    if (!TASK_STATUSES.includes(body.status)) errors.push({ field: 'status', message: 'Status must be pending, in_progress or completed' });
    else patch.status = body.status;
  }
  if (body.priority !== undefined) {
    if (!PRIORITIES.includes(body.priority)) errors.push({ field: 'priority', message: 'Priority must be low, medium or high' });
    else patch.priority = body.priority;
  }
  if (body.completionNotes !== undefined) {
    if (typeof body.completionNotes !== 'string' || body.completionNotes.length > 2000) errors.push({ field: 'completionNotes', message: 'Notes must be text of 2000 characters or fewer' });
    else patch.completionNotes = body.completionNotes.trim();
  }
  if (errors.length) throw new HttpError(400, 'Please fix the highlighted fields', { errors });
  if (body.dueDate !== undefined) patch.dueDate = validateDueDate(body.dueDate, task.dueDate);
  if (patch.status === 'completed' && task.status !== 'completed') patch.completedAt = now();
  if (patch.status && patch.status !== 'completed') patch.completedAt = null;
  patch.updatedAt = now();
  return patch;
}

export function filterAndSortTasks(tasks, q = {}) {
  const today = todayStr();
  const weekEnd = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
  let rows = tasks;
  if (q.status && TASK_STATUSES.includes(q.status)) rows = rows.filter((t) => t.status === q.status);
  if (q.priority && PRIORITIES.includes(q.priority)) rows = rows.filter((t) => t.priority === q.priority);
  if (q.due === 'overdue') rows = rows.filter((t) => t.dueDate && t.dueDate < today && t.status !== 'completed');
  else if (q.due === 'today') rows = rows.filter((t) => t.dueDate === today);
  else if (q.due === 'week') rows = rows.filter((t) => t.dueDate && t.dueDate >= today && t.dueDate <= weekEnd);
  else if (q.due === 'none') rows = rows.filter((t) => !t.dueDate);
  return [...rows].sort((a, b) =>
    (a.status === 'completed') - (b.status === 'completed') ||
    PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority] ||
    (a.dueDate || '9999') .localeCompare(b.dueDate || '9999') ||
    a.createdAt.localeCompare(b.createdAt));
}
