/** Method 1: rule-based validation. Checks form/format only. It says nothing about credibility. */

export const EVIDENCE_TYPES = {
  customer_survey: 'Customer survey',
  customer_interview: 'Customer interview',
  market_research: 'Market research',
  financial_calculation: 'Financial calculation',
  competitor_analysis: 'Competitor analysis',
  official_report: 'Official report',
  experiment_test: 'Experiment or prototype test',
  other: 'Other',
};
export const UNITS = ['percent', 'INR', 'USD', 'count', 'other'];
export const PERIODS = ['day', 'week', 'month', 'quarter', 'year'];

const LIMITS = { title: 200, description: 5000, notes: 2000, url: 2048 };

const str = (v) => (typeof v === 'string' ? v.trim() : v == null ? '' : String(v).trim());
const blank = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');

function parseNumber(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : NaN;
  const s = str(v).replace(/,/g, '');
  if (!/^-?\d+(\.\d+)?$/.test(s)) return NaN;
  return Number(s);
}

export function validateUrl(value) {
  if (value.length > LIMITS.url) return 'URL is too long';
  let u;
  try { u = new URL(value); } catch { return 'Enter a full URL such as https://example.com/report'; }
  if (!['http:', 'https:'].includes(u.protocol)) return 'Only http:// or https:// links are accepted';
  if (u.username || u.password) return 'URLs must not contain a username or password';
  if (!u.hostname.includes('.') && u.hostname !== 'localhost') return 'The URL host looks incomplete';
  return null;
}

/**
 * @returns {{ errors: {field,message}[], missingInfo: string[], clean: object }}
 * errors block saving; missingInfo is informational and is shown to the founder.
 */
export function validateEvidenceInput(body, now = new Date()) {
  const errors = [];
  const missingInfo = [];
  const err = (field, message) => errors.push({ field, message });

  const title = str(body.title);
  const description = str(body.description);
  const type = str(body.type);
  const sourceUrl = str(body.sourceUrl);
  const limitations = str(body.limitations);

  if (!title) err('title', 'Evidence title is required');
  else if (title.length > LIMITS.title) err('title', `Title must be ${LIMITS.title} characters or fewer`);
  if (!description) err('description', 'Evidence description is required');
  else if (description.length > LIMITS.description) err('description', `Description must be ${LIMITS.description} characters or fewer`);
  if (!type) err('type', 'Choose an evidence type');
  else if (!EVIDENCE_TYPES[type]) err('type', 'Unknown evidence type');
  if (limitations.length > LIMITS.notes) err('limitations', `Notes must be ${LIMITS.notes} characters or fewer`);

  if (sourceUrl) {
    const m = validateUrl(sourceUrl);
    if (m) err('sourceUrl', m);
  } else {
    missingInfo.push('No source link provided');
  }

  let evidenceDate = null;
  if (!blank(body.evidenceDate)) {
    const s = str(body.evidenceDate);
    const t = Date.parse(s);
    if (!/^\d{4}-\d{2}-\d{2}/.test(s) || Number.isNaN(t)) err('evidenceDate', 'Enter a valid date (YYYY-MM-DD)');
    else if (new Date(t).getUTCFullYear() < 1990) err('evidenceDate', 'Date is too far in the past');
    else if (t > now.getTime() + 24 * 3600 * 1000) err('evidenceDate', 'Date cannot be in the future');
    else evidenceDate = new Date(t).toISOString().slice(0, 10);
  } else {
    missingInfo.push('No evidence collection/publication date provided');
  }

  const nd = {};
  const numField = (key, label, { integer = false, min = 0 } = {}) => {
    if (blank(body[key])) return;
    const n = parseNumber(body[key]);
    if (Number.isNaN(n)) return err(key, `${label} must be a number`);
    if (n < min) return err(key, `${label} cannot be less than ${min}`);
    if (integer && !Number.isInteger(n)) return err(key, `${label} must be a whole number`);
    if (n > 1e15) return err(key, `${label} is unreasonably large`);
    nd[key] = n;
  };
  numField('sampleSize', 'Sample size', { integer: true, min: 1 });
  numField('positiveCount', 'Positive responses', { integer: true });
  numField('reportedValue', 'Reported value');
  numField('competitorCount', 'Competitor count', { integer: true });

  if (!blank(body.unit)) {
    if (!UNITS.includes(str(body.unit))) err('unit', 'Unknown unit');
    else nd.unit = str(body.unit);
  }
  if (!blank(body.period)) {
    if (!PERIODS.includes(str(body.period))) err('period', 'Unknown period');
    else nd.period = str(body.period);
  }

  if (nd.reportedValue !== undefined && !nd.unit && !errors.some((e) => e.field === 'unit')) {
    err('unit', 'Choose a unit for the reported value');
  }
  if (nd.unit === 'percent' && nd.reportedValue > 100) err('reportedValue', 'A percentage cannot exceed 100');
  if (nd.positiveCount !== undefined && nd.sampleSize === undefined && !errors.some((e) => e.field === 'sampleSize')) {
    err('sampleSize', 'Sample size is required when you report a number of positive responses');
  }
  if (nd.positiveCount !== undefined && nd.sampleSize !== undefined && nd.positiveCount > nd.sampleSize) {
    err('positiveCount', 'Positive responses cannot exceed the sample size');
  }

  if (['customer_survey', 'customer_interview'].includes(type) && nd.sampleSize === undefined) {
    missingInfo.push('Sample size not provided for a survey/interview');
  }
  if (type === 'customer_survey' && nd.sampleSize !== undefined && nd.positiveCount === undefined && nd.reportedValue === undefined) {
    missingInfo.push('Survey results (positive responses or a reported percentage) not provided as numbers');
  }

  return {
    errors,
    missingInfo,
    clean: { title, description, type, sourceUrl, evidenceDate, limitations, numericalData: nd },
  };
}
