import { HttpError } from '../http.js';
import { ensureTask, contradictionTaskSpec } from './tasks.js';

export const CONTRADICTION_STATUSES = ['open', 'under_review', 'resolved', 'dismissed'];
const SEV_RANK = { low: 0, medium: 1, high: 2 };
const now = () => new Date().toISOString();

export async function addEvent(ctx, contradictionId, startupId, type, note, actor = 'system') {
  return ctx.store.collection('contradiction_events').insert({ contradictionId, startupId, type, note, actor, at: now() });
}

/**
 * Called after every (re)validation of a piece of evidence. Never auto-resolves anything.
 * Returns { contradiction, created, task } (contradiction may be null).
 */
export async function reconcileContradictions(ctx, { startup, claim, evidence, status, numeric, semantic, actor }) {
  const col = ctx.store.collection('contradictions');
  const all = await col.find({ startupId: startup._id, claimIds: claim._id });
  const active = all.filter((c) => ['open', 'under_review'].includes(c.status));
  const sameEvidence = all.filter((c) => c.evidenceIds.includes(evidence._id));

  if (status === 'contradicting') {
    if (sameEvidence.length) {
      const c = sameEvidence[0];
      await addEvent(ctx, c._id, startup._id, 'revalidated', `Evidence "${evidence.title}" was re-validated and still conflicts with the claim.`, actor);
      return { contradiction: c, created: false, task: null };
    }
    const numericHit = numeric?.applicable && numeric.status === 'contradicting';
    const semanticHit = semantic?.ok && semantic.result.status === 'contradicting';
    const method = numericHit && semanticHit ? 'combined' : numericHit ? 'numeric' : 'semantic';
    const severity = numericHit ? numeric.severity || 'medium' : 'medium';
    const description = numericHit ? numeric.explanation : semantic.result.explanation;

    if (active.length) {
      const c = active[0];
      const evidenceIds = [...c.evidenceIds, evidence._id];
      const sev = SEV_RANK[severity] > SEV_RANK[c.severity] ? severity : c.severity;
      const updated = await ctx.store.collection('contradictions').update(c._id, { evidenceIds, severity: sev, updatedAt: now() });
      await addEvent(ctx, c._id, startup._id, 'evidence_added', `Additional conflicting evidence attached: "${evidence.title}". ${description}`, actor);
      return { contradiction: updated, created: false, task: null };
    }

    const ts = now();
    const title = `Evidence conflicts with claim: ${claim.claimText}`.slice(0, 160);
    const c = await col.insert({
      startupId: startup._id,
      claimIds: [claim._id],
      evidenceIds: [evidence._id],
      title,
      description,
      reason: `Detected by ${method} validation of submitted evidence "${evidence.title}". This is an automatic, potential finding that needs your review.`,
      detectionMethod: method,
      severity,
      status: 'open',
      confirmation: 'potential',
      resolutionNotes: '',
      detectedAt: ts,
      reviewedAt: null,
      updatedAt: ts,
    });
    await addEvent(ctx, c._id, startup._id, 'detected', description, 'system');
    const { task } = await ensureTask(ctx, startup._id, contradictionTaskSpec(claim, c), { followUp: true });
    return { contradiction: c, created: true, task };
  }

  // Evidence is not (or no longer) contradicting. Record context but never change status automatically.
  for (const c of sameEvidence.filter((x) => ['open', 'under_review'].includes(x.status))) {
    await addEvent(ctx, c._id, startup._id, 'note', `Re-validation of "${evidence.title}" now gives "${status}". The contradiction stays ${c.status.replace('_', ' ')} until you review it.`, actor);
  }
  if (status === 'supporting') {
    for (const c of active.filter((x) => !x.evidenceIds.includes(evidence._id))) {
      await addEvent(ctx, c._id, startup._id, 'note', `New supporting evidence was submitted ("${evidence.title}"). Review whether it addresses this contradiction; it has not been resolved automatically.`, actor);
    }
  }
  return { contradiction: null, created: false, task: null };
}

const TRANSITIONS = {
  open: ['under_review', 'resolved', 'dismissed'],
  under_review: ['open', 'resolved', 'dismissed'],
  resolved: ['open'],
  dismissed: ['open'],
};

export async function updateContradiction(ctx, contradiction, body, user) {
  const status = body.status;
  const notes = typeof body.notes === 'string' ? body.notes.trim() : '';
  if (!CONTRADICTION_STATUSES.includes(status)) {
    throw new HttpError(400, 'Status must be open, under_review, resolved or dismissed', { errors: [{ field: 'status', message: 'Invalid status' }] });
  }
  if (!TRANSITIONS[contradiction.status].includes(status)) {
    throw new HttpError(409, `Cannot change a ${contradiction.status.replace('_', ' ')} contradiction to ${status.replace('_', ' ')}`);
  }
  if (notes.length > 2000) throw new HttpError(400, 'Notes must be 2000 characters or fewer', { errors: [{ field: 'notes', message: 'Too long' }] });
  if (['resolved', 'dismissed'].includes(status) && notes.length < 5) {
    throw new HttpError(400, `Please explain why you are marking this ${status} (at least 5 characters)`, { errors: [{ field: 'notes', message: 'An explanation is required' }] });
  }
  if (contradiction.status !== 'open' && status === 'open' && notes.length < 5) {
    throw new HttpError(400, 'Please explain why you are reopening this contradiction', { errors: [{ field: 'notes', message: 'An explanation is required' }] });
  }
  const ts = now();
  const patch = { status, updatedAt: ts, reviewedAt: status === 'open' ? null : ts };
  if (status === 'resolved') patch.confirmation = 'confirmed';
  if (status === 'dismissed') patch.confirmation = 'false_positive';
  if (status === 'open') patch.confirmation = 'potential';
  if (['resolved', 'dismissed'].includes(status)) patch.resolutionNotes = notes;
  const updated = await ctx.store.collection('contradictions').update(contradiction._id, patch);
  await addEvent(ctx, contradiction._id, contradiction.startupId, 'status_changed',
    `Status changed from ${contradiction.status.replace('_', ' ')} to ${status.replace('_', ' ')}${notes ? `: ${notes}` : ''}`, user.name || user.id);
  return updated;
}
