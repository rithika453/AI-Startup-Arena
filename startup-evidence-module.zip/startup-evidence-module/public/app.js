// Dashboard for the three Member 5 screens. Plain ES modules, no build step.
// All dynamic text is inserted with textContent (never innerHTML), so submitted evidence cannot inject markup.

const $ = (s, r = document) => r.querySelector(s);
const VAL = { not_validated: 'Not Yet Validated', supporting: 'Supporting Evidence', contradicting: 'Contradicting Evidence', insufficient: 'Insufficient Evidence', unrelated: 'Unrelated Evidence' };
const SRC = { not_checked: 'Not Checked', accessible: 'Accessible', unavailable: 'Unavailable', independently_reviewed: 'Independently Reviewed' };
const CSTATUS = { open: 'Open', under_review: 'Under Review', resolved: 'Resolved', dismissed: 'Dismissed' };
const TSTATUS = { pending: 'Pending', in_progress: 'In Progress', completed: 'Completed' };
const CONF = { potential: 'Potential finding', confirmed: 'Confirmed', false_positive: 'False positive' };
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

const S = {
  token: '', startupId: '', me: null, view: 'evidence', aiConfigured: false,
  claims: [], types: {}, selectedClaim: null, evidence: {}, lastResult: null,
  tlOrder: 'desc', tlStatus: '', act: null, detail: {},
  taskFilters: { status: '', priority: '', due: '' },
};

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return el;
}
const badge = (cls, text) => h('span', { class: `badge ${cls}` }, text);
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '—');

function toast(msg, error = false) {
  const t = h('div', { class: `toast${error ? ' error' : ''}` }, msg);
  $('#toasts').append(t);
  setTimeout(() => t.remove(), error ? 7000 : 4500);
}

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${S.token}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch { /* non-JSON error */ }
  if (res.status === 401) { showConnect('Your session expired or the token is invalid. Please connect again.'); }
  if (!res.ok) {
    const e = new Error(data.error || 'Request failed');
    e.status = res.status; e.data = data;
    throw e;
  }
  return data;
}

const loading = (label = 'Loading…') => h('p', { class: 'muted', role: 'status' }, h('span', { class: 'spinner' }), label);
const view = () => $('#view');
function setView(...nodes) { view().replaceChildren(...nodes.flat().filter((n) => n && n !== '')); }

// ---------------------------------------------------------------- connect
function decodeSub(token) {
  try { return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).sub || null; } catch { return null; }
}
function showConnect(msg) {
  $('#connect').hidden = false; $('#tabs').hidden = true;
  setView(msg ? h('div', { class: 'alert warn', role: 'alert' }, msg) : '');
}
async function connect(token, startupId) {
  S.token = token; S.startupId = startupId; S.me = decodeSub(token);
  try { sessionStorage.setItem('m5', JSON.stringify({ token, startupId })); } catch { /* storage unavailable */ }
  $('#connect').hidden = true; $('#tabs').hidden = false;
  await go(S.view);
}
$('#connect-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const t = $('#f-token').value.trim(); const s = $('#f-startup').value.trim();
  if (!t || !s) return toast('Enter both the login token and the startup ID.', true);
  connect(t, s);
});
$('#btn-demo').addEventListener('click', async () => {
  const r = await fetch('/api/demo/login', { method: 'POST' });
  if (!r.ok) return toast('Demo login is not available.', true);
  const d = await r.json();
  connect(d.token, d.startupId);
});

// ---------------------------------------------------------------- navigation
document.querySelectorAll('#tabs [role=tab]').forEach((b) => b.addEventListener('click', () => go(b.dataset.view)));
async function go(name) {
  S.view = name;
  document.querySelectorAll('#tabs [role=tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.view === name)));
  setView(loading());
  try {
    if (name === 'evidence') await renderEvidence();
    else if (name === 'timeline') await renderTimeline();
    else await renderTasks();
  } catch (e) {
    if (e.status !== 401) setView(h('div', { class: 'alert bad', role: 'alert' }, e.status === 404 ? 'This startup was not found, or you do not have access to it.' : `Could not load this page: ${e.message}`));
  }
  refreshCounts();
}
async function refreshCounts() {
  try {
    const [c, t] = await Promise.all([api(`/startups/${S.startupId}/contradictions`), api(`/startups/${S.startupId}/tasks`)]);
    const open = c.contradictions.filter((x) => ['open', 'under_review'].includes(x.status)).length;
    const todo = t.tasks.filter((x) => x.status !== 'completed').length;
    for (const [id, n] of [['#cnt-timeline', open], ['#cnt-tasks', todo]]) { $(id).hidden = !n; $(id).textContent = n; }
  } catch { /* counts are cosmetic */ }
}

// ---------------------------------------------------------------- screen 1: evidence
async function renderEvidence() {
  const data = await api(`/startups/${S.startupId}/claims`);
  S.claims = data.claims; S.types = data.evidenceTypes;
  $('#startup-name').textContent = data.startup.name || 'Startup';
  $('#demo-badge').hidden = !data.startup.demo;
  if (!S.claims.length) {
    return setView(h('div', { class: 'card empty' }, h('h2', {}, 'No claims yet'),
      h('p', {}, 'The AI evaluation has not produced any claims for this startup. Run the startup evaluation first, then come back to attach evidence.')));
  }
  if (!S.claims.some((c) => c._id === S.selectedClaim)) S.selectedClaim = S.claims[0]._id;
  const claim = S.claims.find((c) => c._id === S.selectedClaim);
  const ev = (await api(`/startups/${S.startupId}/evidence?claimId=${encodeURIComponent(claim._id)}`)).evidence;

  const list = h('ul', { class: 'claim-list', 'aria-label': 'AI-generated claims' }, S.claims.map((c) =>
    h('li', {}, h('button', { class: 'claim-btn', 'aria-current': c._id === S.selectedClaim ? 'true' : 'false', onclick: () => { S.selectedClaim = c._id; S.lastResult = null; go('evidence'); } },
      h('strong', {}, c.claimText),
      h('div', { class: 'meta' }, badge(c.evidenceStatus, VAL[c.evidenceStatus]), h('span', {}, `${c.evidenceCount} evidence`), h('span', {}, c.category))))));

  const right = h('div', {},
    h('div', { class: 'card' },
      h('h2', {}, claim.claimText),
      claim.description && h('p', {}, claim.description),
      h('dl', { class: 'kv' },
        h('dt', {}, 'Category'), h('dd', {}, claim.category),
        h('dt', {}, 'Origin'), h('dd', {}, claim.origin),
        h('dt', {}, 'Evidence status'), h('dd', {}, badge(claim.evidenceStatus, VAL[claim.evidenceStatus]), ' ', claim.statusNote),
        h('dt', {}, 'Evidence records'), h('dd', {}, String(claim.evidenceCount))),
      h('p', { class: 'note' }, 'Evidence being present is not proof that a claim is true. The statuses below describe how the submitted information compares with the claim.')),
    resultBanner(),
    evidenceForm(claim),
    h('h2', { class: 'mt16' }, 'Evidence for this claim'),
    ev.length ? ev.map(evidenceCard) : h('div', { class: 'card empty' }, 'No evidence submitted for this claim yet.'));
  setView(h('div', { class: 'layout' }, h('div', {}, h('h2', {}, 'Claims'), list), right));
}

function resultBanner() {
  const r = S.lastResult;
  if (!r) return '';
  const parts = [];
  if (r.contradictionCreated) parts.push(h('div', { class: 'alert bad', role: 'alert' }, 'A potential contradiction was detected and added to the timeline. ', h('button', { class: 'btn small', onclick: () => go('timeline') }, 'View timeline')));
  if (r.task && r.contradictionCreated) parts.push(h('div', { class: 'alert info' }, `Suggested task: ${r.task.title} `, h('button', { class: 'btn small', onclick: () => go('tasks') }, 'View tasks')));
  if (r.validationPending) parts.push(h('div', { class: 'alert warn', role: 'alert' }, 'Your evidence was saved, but it could not be assessed automatically (the AI analysis was unavailable and there were no comparable numbers). It is waiting for review. Use "Re-run validation" later.'));
  if (r.missingInformation?.length) parts.push(h('div', { class: 'alert warn' }, h('strong', {}, 'Information missing from your submission:'), h('ul', { class: 'plain' }, r.missingInformation.map((m) => h('li', {}, m)))));
  return h('div', {}, parts);
}

function field(name, label, control, errors, hint) {
  const err = errors?.[name];
  control.id = `ev-${name}`;
  if (err) { control.setAttribute('aria-invalid', 'true'); control.setAttribute('aria-describedby', `err-${name}`); }
  return h('label', { for: `ev-${name}` }, label, hint && h('small', {}, hint), control, err && h('span', { class: 'field-error', id: `err-${name}` }, err));
}

function evidenceForm(claim, errors = null, values = {}) {
  const input = (type, name, extra = {}) => h('input', { type, name, value: values[name] ?? '', ...extra });
  const typeSel = h('select', { name: 'type' }, h('option', { value: '' }, 'Choose a type…'),
    Object.entries(S.types).map(([k, v]) => h('option', { value: k, selected: values.type === k }, v)));
  const unitSel = h('select', { name: 'unit' }, h('option', { value: '' }, '—'),
    [['percent', '% (percent)'], ['INR', '₹ (INR)'], ['USD', '$ (USD)'], ['count', 'Count'], ['other', 'Other']].map(([k, v]) => h('option', { value: k, selected: values.unit === k }, v)));
  const periodSel = h('select', { name: 'period' }, h('option', { value: '' }, '—'),
    ['day', 'week', 'month', 'quarter', 'year'].map((p) => h('option', { value: p, selected: values.period === p }, cap(p))));
  const form = h('form', { class: 'grid-form', novalidate: true, 'aria-label': 'Add evidence' },
    h('div', { class: 'wide' }, field('title', 'Evidence title *', input('text', 'title', { maxlength: 200, required: true }), errors)),
    h('div', { class: 'wide' }, field('description', 'Description *', h('textarea', { name: 'description', maxlength: 5000 }, values.description || ''), errors, 'What was done, who was asked/what was measured, and what was found.')),
    field('type', 'Evidence type *', typeSel, errors),
    field('sourceUrl', 'Source URL', input('url', 'sourceUrl', { placeholder: 'https://…' }), errors, 'Optional'),
    field('evidenceDate', 'Collected / published on', input('date', 'evidenceDate'), errors, 'Optional'),
    field('sampleSize', 'Sample size', input('number', 'sampleSize', { min: 1, step: 1 }), errors, 'Respondents, interviews…'),
    field('positiveCount', 'Positive responses', input('number', 'positiveCount', { min: 0, step: 1 }), errors, 'e.g. how many said they are interested'),
    field('competitorCount', 'Competitors found', input('number', 'competitorCount', { min: 0, step: 1 }), errors),
    h('fieldset', { class: 'wide' }, h('legend', {}, 'A single reported number (optional)'),
      h('div', { class: 'grid-form' },
        field('reportedValue', 'Value', input('number', 'reportedValue', { step: 'any', min: 0 }), errors),
        field('unit', 'Unit', unitSel, errors),
        field('period', 'Per period', periodSel, errors, 'Needed to compare costs per month/year'))),
    h('div', { class: 'wide' }, field('limitations', 'Known limitations', h('textarea', { name: 'limitations', maxlength: 2000 }, values.limitations || ''), errors, 'Optional: bias, small sample, self-reported…')),
    h('div', { class: 'wide row' }, h('button', { class: 'btn primary', type: 'submit' }, 'Submit and validate'),
      h('span', { class: 'muted' }, 'Validation uses only what you enter here; linked sources are not opened or verified.')));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(form).entries());
    const btn = $('button[type=submit]', form); btn.disabled = true; btn.replaceChildren(h('span', { class: 'spinner' }), 'Validating…');
    try {
      const r = await api(`/startups/${S.startupId}/evidence`, { method: 'POST', body: { ...fd, claimId: claim._id } });
      S.lastResult = r;
      toast('Evidence saved.');
      await go('evidence');
    } catch (err) {
      btn.disabled = false; btn.textContent = 'Submit and validate';
      if (err.status === 400 && err.data?.errors) {
        const map = Object.fromEntries(err.data.errors.map((x) => [x.field, x.message]));
        form.replaceWith(evidenceForm(claim, map, fd));
        toast('Please fix the highlighted fields.', true);
        const first = $('[aria-invalid=true]'); if (first) first.focus();
      } else if (err.status === 409) toast('This exact evidence was already submitted for this claim.', true);
      else if (err.status !== 401) toast(err.message, true);
    }
  });
  const box = h('details', { class: 'card mt12', open: true }, h('summary', {}, 'Add evidence for this claim'), h('div', { class: 'mt10' }, form));
  return box;
}

function numbersList(nd = {}) {
  const items = [];
  if (nd.sampleSize != null) items.push(['Sample size', nd.sampleSize]);
  if (nd.positiveCount != null) items.push(['Positive responses', nd.positiveCount]);
  if (nd.competitorCount != null) items.push(['Competitors found', nd.competitorCount]);
  if (nd.reportedValue != null) items.push(['Reported value', `${nd.reportedValue} ${nd.unit || ''}${nd.period ? ` / ${nd.period}` : ''}`]);
  return items;
}

function evidenceCard(e) {
  const d = e.validationDetails || {};
  const nums = numbersList(e.numericalData);
  const missing = [...new Set([...(e.ruleMissingInfo || []), ...(d.missingInformation || [])])];
  const historyBox = h('div', {});
  const card = h('article', { class: 'card', 'aria-label': e.title },
    h('div', { class: 'row between' }, h('h3', {}, e.title),
      h('div', { class: 'row' }, badge(e.validationStatus, VAL[e.validationStatus]), badge(e.sourceVerificationStatus, `Source: ${SRC[e.sourceVerificationStatus]}`))),
    h('p', { class: 'muted' }, `${S.types[e.type] || e.type} · submitted ${fmtDate(e.createdAt)}${e.evidenceDate ? ` · dated ${e.evidenceDate}` : ''}`),
    h('p', {}, e.description),
    e.sourceUrl && h('p', {}, h('a', { href: e.sourceUrl, target: '_blank', rel: 'noopener noreferrer nofollow' }, e.sourceUrl)),
    nums.length ? h('dl', { class: 'kv' }, nums.map(([k, v]) => [h('dt', {}, k), h('dd', {}, String(v))])) : '',
    h('div', { class: 'alert info' }, h('strong', {}, 'Why this status: '), e.validationExplanation),
    d.supportingPoints?.length ? h('div', {}, h('strong', {}, 'Points in favour'), h('ul', { class: 'plain' }, d.supportingPoints.map((x) => h('li', {}, x)))) : '',
    d.contradictingPoints?.length ? h('div', {}, h('strong', {}, 'Points against'), h('ul', { class: 'plain' }, d.contradictingPoints.map((x) => h('li', {}, x)))) : '',
    d.limitations?.length ? h('div', {}, h('strong', {}, 'Limitations'), h('ul', { class: 'plain' }, d.limitations.map((x) => h('li', {}, x)))) : '',
    missing.length ? h('div', {}, h('strong', {}, 'Missing information'), h('ul', { class: 'plain' }, missing.map((x) => h('li', {}, x)))) : '',
    h('p', { class: 'note' }, e.caveat),
    h('div', { class: 'row' },
      h('button', { class: 'btn small', onclick: async (ev) => {
        const b = ev.currentTarget; b.disabled = true; b.textContent = 'Validating…';
        try { const r = await api(`/evidence/${e._id}/validate`, { method: 'POST' }); S.lastResult = { ...r, contradictionCreated: r.contradictionCreated }; toast(r.validationPending ? 'Still could not be assessed. Evidence remains pending.' : 'Validation updated.', r.validationPending); await go('evidence'); }
        catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Re-run validation'; }
      } }, 'Re-run validation'),
      e.submittedBy !== S.me && e.sourceVerificationStatus !== 'independently_reviewed' ? sourceReviewForm(e) : ''),
    h('details', { ontoggle: async (ev) => {
      if (!ev.target.open || historyBox.dataset.loaded) return;
      historyBox.replaceChildren(loading());
      try {
        const r = await api(`/evidence/${e._id}`);
        historyBox.dataset.loaded = '1';
        historyBox.replaceChildren(...r.history.map((hh) => h('div', { class: 'hist' }, h('strong', {}, fmtDate(hh.at)), ' ', badge(hh.status, VAL[hh.status]), ` (${hh.methods.join(', ')}${hh.aiAvailable ? '' : '; AI unavailable'})`, h('div', { class: 'muted' }, hh.explanation))));
      } catch (err) { historyBox.replaceChildren(h('span', { class: 'field-error' }, 'Could not load history.')); }
    } }, h('summary', {}, 'Validation history'), historyBox));
  return card;
}

function sourceReviewForm(e) {
  const note = h('textarea', { 'aria-label': 'What did you check?', placeholder: 'What did you check in the source?' });
  return h('details', {}, h('summary', {}, 'Mark source as independently reviewed'),
    note, h('button', { class: 'btn small', onclick: async () => {
      try { await api(`/evidence/${e._id}/source-review`, { method: 'POST', body: { note: note.value } }); toast('Source marked as independently reviewed.'); go('evidence'); }
      catch (err) { toast(err.data?.errors?.[0]?.message || err.message, true); }
    } }, 'Save review'));
}

// ---------------------------------------------------------------- screen 2: timeline
async function renderTimeline() {
  const q = new URLSearchParams({ order: S.tlOrder }); if (S.tlStatus) q.set('status', S.tlStatus);
  const { contradictions } = await api(`/startups/${S.startupId}/contradictions?${q}`);
  const filters = h('div', { class: 'filters' },
    h('label', {}, 'Status', h('select', { onchange: (e) => { S.tlStatus = e.target.value; go('timeline'); } }, h('option', { value: '' }, 'All'), Object.entries(CSTATUS).map(([k, v]) => h('option', { value: k, selected: S.tlStatus === k }, v)))),
    h('label', {}, 'Order', h('select', { onchange: (e) => { S.tlOrder = e.target.value; go('timeline'); } }, h('option', { value: 'desc', selected: S.tlOrder === 'desc' }, 'Newest first'), h('option', { value: 'asc', selected: S.tlOrder === 'asc' }, 'Oldest first'))));
  const intro = h('p', { class: 'note' }, 'These are potential findings detected automatically when evidence conflicts with a claim. Nothing is resolved automatically: review each one, then resolve it or dismiss it as a false positive with a reason.');
  if (!contradictions.length) {
    return setView(h('h2', {}, 'Contradiction timeline'), intro, filters, h('div', { class: 'card empty' }, S.tlStatus ? 'No contradictions with this status.' : 'No contradictions detected. Conflicts appear here when submitted evidence disagrees with a claim.'));
  }
  setView(h('h2', {}, 'Contradiction timeline'), intro, filters, h('ol', { class: 'timeline', 'aria-label': 'Contradictions' }, contradictions.map(timelineEntry)));
}

function timelineEntry(c) {
  const detailBox = h('div', {});
  const actions = h('div', { class: 'row' });
  const reload = () => go('timeline');
  const patch = async (status, notes) => {
    try { await api(`/contradictions/${c._id}`, { method: 'PATCH', body: { status, notes } }); S.act = null; toast(`Marked ${CSTATUS[status].toLowerCase()}.`); reload(); }
    catch (err) { toast(err.data?.errors?.[0]?.message || err.message, true); }
  };
  if (c.status === 'open') actions.append(h('button', { class: 'btn small', onclick: () => patch('under_review') }, 'Mark under review'));
  if (['open', 'under_review'].includes(c.status)) {
    actions.append(h('button', { class: 'btn small', onclick: () => { S.act = { id: c._id, kind: 'resolved' }; reload(); } }, 'Resolve…'),
      h('button', { class: 'btn small', onclick: () => { S.act = { id: c._id, kind: 'dismissed' }; reload(); } }, 'Dismiss as false positive…'));
  } else actions.append(h('button', { class: 'btn small', onclick: () => { S.act = { id: c._id, kind: 'open' }; reload(); } }, 'Reopen…'));
  actions.append(h('button', { class: 'btn small', onclick: () => { S.selectedClaim = c.claimIds[0]; go('evidence'); } }, 'Open claim and evidence'));

  let form = '';
  if (S.act?.id === c._id) {
    const label = { resolved: 'How was this resolved?', dismissed: 'Why is this a false positive?', open: 'Why are you reopening this?' }[S.act.kind];
    const ta = h('textarea', { id: `n-${c._id}`, 'aria-label': label, required: true });
    form = h('div', { class: 'card mt8' }, h('label', { for: ta.id }, label, ta),
      h('div', { class: 'row mt8' }, h('button', { class: 'btn primary small', onclick: () => patch(S.act.kind, ta.value) }, 'Save'), h('button', { class: 'btn small', onclick: () => { S.act = null; reload(); } }, 'Cancel')));
  }

  const toggle = h('details', { ontoggle: async (ev) => {
    if (!ev.target.open || detailBox.dataset.loaded) return;
    detailBox.replaceChildren(loading());
    try {
      const r = await api(`/contradictions/${c._id}`);
      detailBox.dataset.loaded = '1';
      detailBox.replaceChildren(
        h('h4', {}, 'Original claim'), ...r.claims.map((cl) => h('p', {}, h('strong', {}, cl.claimText), cl.description ? ` — ${cl.description}` : '')),
        h('h4', {}, 'Relevant evidence'), ...r.evidence.map((ev2) => h('div', { class: 'hist' }, h('strong', {}, ev2.title), ' ', badge(ev2.validationStatus, VAL[ev2.validationStatus]), h('div', {}, ev2.description), h('div', { class: 'muted' }, ev2.validationExplanation))),
        h('h4', {}, 'History'), ...r.events.map((en) => h('div', { class: 'hist' }, h('strong', {}, fmtDate(en.at)), ` · ${en.type.replace('_', ' ')} · `, en.note)));
    } catch { detailBox.replaceChildren(h('span', { class: 'field-error' }, 'Could not load details.')); }
  } }, h('summary', {}, 'Details and history'), detailBox);

  return h('li', {}, h('article', { class: 'card', 'aria-label': c.title },
    h('p', { class: 'muted' }, fmtDate(c.detectedAt)),
    h('div', { class: 'row between' }, h('h3', {}, c.title),
      h('div', { class: 'row' }, badge(c.severity, `${cap(c.severity)} severity`), badge(c.status, CSTATUS[c.status]), badge(c.confirmation === 'potential' ? 'potential' : c.confirmation === 'confirmed' ? 'resolved' : 'neutral', CONF[c.confirmation]))),
    h('p', {}, c.description),
    h('dl', { class: 'kv' },
      h('dt', {}, 'Related claim'), h('dd', {}, c.claims.map((x) => x.claimText).join('; ')),
      h('dt', {}, 'Related evidence'), h('dd', {}, c.evidence.map((x) => x.title).join('; ')),
      h('dt', {}, 'Detected by'), h('dd', {}, `${c.detectionMethod} validation`),
      c.resolutionNotes ? [h('dt', {}, 'Resolution notes'), h('dd', {}, c.resolutionNotes)] : ''),
    h('p', { class: 'note' }, c.reason),
    actions, form, toggle));
}

// ---------------------------------------------------------------- screen 3: tasks
async function renderTasks() {
  const f = S.taskFilters;
  const q = new URLSearchParams(Object.entries(f).filter(([, v]) => v));
  const { tasks, total } = await api(`/startups/${S.startupId}/tasks?${q}`);
  const sel = (key, label, opts) => h('label', {}, label, h('select', { onchange: (e) => { S.taskFilters[key] = e.target.value; go('tasks'); } }, h('option', { value: '' }, 'All'), Object.entries(opts).map(([k, v]) => h('option', { value: k, selected: f[key] === k }, v))));
  const gen = h('button', { class: 'btn primary', onclick: async (ev) => {
    const b = ev.currentTarget; b.disabled = true; b.textContent = 'Checking weaknesses…';
    try { const r = await api(`/startups/${S.startupId}/tasks`, { method: 'POST', body: { generate: true } }); toast(r.created.length ? `${r.created.length} new task(s) created.` : 'No new tasks. Existing tasks already cover every current weakness.'); go('tasks'); }
    catch (err) { toast(err.message, true); b.disabled = false; b.textContent = 'Generate tasks from weaknesses'; }
  } }, 'Generate tasks from weaknesses');
  const head = [h('div', { class: 'row between' }, h('h2', {}, 'Weakness-to-action tasks'), gen),
    h('p', { class: 'note' }, 'Completing a task does not mean the weakness is fixed. Submit what you learned as evidence on the related claim so it can be assessed.'),
    h('div', { class: 'filters' }, sel('status', 'Status', TSTATUS), sel('priority', 'Priority', { high: 'High', medium: 'Medium', low: 'Low' }),
      sel('due', 'Due date', { overdue: 'Overdue', today: 'Due today', week: 'Due within 7 days', none: 'No due date' }))];
  if (!tasks.length) {
    return setView(...head, h('div', { class: 'card empty' }, total ? 'No tasks match these filters.' : 'No outstanding tasks. Use "Generate tasks from weaknesses" to turn gaps and conflicts into next steps.'));
  }
  setView(...head, tasks.map(taskCard));
}

function taskCard(t) {
  const today = new Date().toISOString().slice(0, 10);
  const status = h('select', { id: `ts-${t._id}`, name: 'status' }, Object.entries(TSTATUS).map(([k, v]) => h('option', { value: k, selected: t.status === k }, v)));
  const prio = h('select', { id: `tp-${t._id}`, name: 'priority' }, ['high', 'medium', 'low'].map((k) => h('option', { value: k, selected: t.priority === k }, cap(k))));
  const due = h('input', { id: `td-${t._id}`, type: 'date', value: t.dueDate || '', min: t.dueDate && t.dueDate < today ? t.dueDate : today });
  const notes = h('textarea', { id: `tn-${t._id}`, maxlength: 2000 }, t.completionNotes || '');
  const err = h('span', { class: 'field-error', role: 'alert' });
  const save = h('button', { class: 'btn primary small', onclick: async () => {
    err.textContent = '';
    try {
      const r = await api(`/tasks/${t._id}`, { method: 'PATCH', body: { status: status.value, priority: prio.value, dueDate: due.value || null, completionNotes: notes.value } });
      toast('Task updated.');
      if (r.nextStep) { S.selectedClaim = r.nextStep.claimId; toast(r.nextStep.message); }
      go('tasks');
    } catch (e) { err.textContent = e.data?.errors?.map((x) => x.message).join(' ') || e.message; }
  } }, 'Save changes');
  const overdue = t.dueDate && t.dueDate < today && t.status !== 'completed';
  return h('article', { class: 'card', 'aria-label': t.title },
    h('div', { class: 'row between' }, h('h3', {}, t.title),
      h('div', { class: 'row' }, badge(t.priority, `${cap(t.priority)} priority`), badge(t.status, TSTATUS[t.status]), t.dueDate && badge(overdue ? 'open' : 'neutral', `${overdue ? 'Overdue: ' : 'Due '}${t.dueDate}`))),
    h('p', { class: 'prewrap' }, t.description),
    h('dl', { class: 'kv' },
      h('dt', {}, 'Related weakness'), h('dd', {}, t.weakness),
      h('dt', {}, 'Why generated'), h('dd', {}, t.reason),
      t.claim ? [h('dt', {}, 'Related claim'), h('dd', {}, t.claim.claimText)] : '',
      t.contradiction ? [h('dt', {}, 'Contradiction'), h('dd', {}, `${t.contradiction.title} (${CSTATUS[t.contradiction.status]})`)] : '',
      t.completionNotes && t.status === 'completed' ? [h('dt', {}, 'Completion notes'), h('dd', {}, t.completionNotes)] : '',
      t.completedAt ? [h('dt', {}, 'Completed'), h('dd', {}, fmtDate(t.completedAt))] : ''),
    h('div', { class: 'grid-form' },
      h('label', { for: status.id }, 'Status', status), h('label', { for: prio.id }, 'Priority', prio),
      h('label', { for: due.id }, 'Due date', due),
      h('label', { for: notes.id }, 'Completion notes', notes)),
    err,
    h('div', { class: 'row mt8' }, save,
      t.claim && h('button', { class: 'btn small', onclick: () => { S.selectedClaim = t.relatedClaimId; go('evidence'); } }, 'Add evidence to this claim'),
      t.contradiction && h('button', { class: 'btn small', onclick: () => go('timeline') }, 'View contradiction')));
}

// ---------------------------------------------------------------- boot
(async function boot() {
  let cfg = { demoMode: false };
  try { cfg = await (await fetch('/api/config')).json(); } catch { /* offline */ }
  $('#btn-demo').hidden = !cfg.demoMode;
  let saved = null;
  try { saved = JSON.parse(sessionStorage.getItem('m5') || 'null'); } catch { /* ignore */ }
  if (saved?.token && saved?.startupId) return connect(saved.token, saved.startupId);
  if (cfg.demoMode) { $('#btn-demo').click(); return; }
  showConnect();
})();
